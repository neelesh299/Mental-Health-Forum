<?php
session_start();
//__________________________HEADER __________________________________________________________
define('BASE_URL', $_SERVER["DOCUMENT_ROOT"].'/BTP');
include(BASE_URL.'/src/header/header.php'); // INCLUDE HEADER FILE
//____________________________HEADER_________________________________________________________
?>


<div class="container-fluid" style="margin-top:50px">
	
	<div class="row">
		<div class="col-md-3">
			<!-- Sidebar -->
		</div>
		<div class="col-md-9">
			<h1>Error 404: Page not Found!</h1><br>
			<a class="btn btn-primary" role="button" href="http://localhost/BTP/index.php">Return to Home</a>
		</div>
	</div>
</div>


<?php
	include(BASE_URL.'/src/header/footer.php'); // Includes Script
?>
