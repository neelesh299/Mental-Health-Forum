<?php
session_start();
//__________________________HEADER __________________________________________________________
define('BASE_URL', $_SERVER["DOCUMENT_ROOT"].'/BTP');
include(BASE_URL.'/src/header/header.php'); // INCLUDE HEADER FILE
//____________________________HEADER_________________________________________________________
?>

<div class="container-fluid" style="margin-top:50px">
	<h1>Mental Health : Forum , Feed and Statistics</h1><br>
	<div class="row">
		<div class="col-md-1">
			<!-- Sidebar -->
		</div>
		<div class="col-md-10">
			<h3>Moderation Policy</h3>
			<p>
				This Moderation Policy governs the manner in which [Website/Platform name] moderates infor-
mation like posts/comments collected from users (each, a ”User”) of the [URL of the platform] web-
site (”Site”). We encourage user participation via open and lively discussions through comments and
posts(stories). But the decision to publish those posts/comments remains at the discretion of the moder-
ators/admin of the platform.<br>
We request our users (each, a User) to keep in mind our guidelines while posting stories and com-
ments on this platform. The views expressed by any user/individual is solely their own and not promoted
by any of the moderators of this channel.<br><br>
<b>Post Policy</b><br>
After submitting your post for publishing, your post goes to the volunteer moderators of this platform to
review for things that you might have written against our community rules, specially around things that
users are not allowed to discuss here, such as medication names, ways of suicide or self harm, heavy
swear words, hate speech against a community/religion/gender/race etc.<br>
Users will be able to check the status of their stories on the stories tab on the dashboard after logging-
in to the platform. On an average it can take up to 3-8 hours to review a particular post. If your post is
not suited to our community rules, it will be saved as a Draft. You are free to edit the post again and
submit for review as many times as you want. It will be published once a moderator decides that it is
in accordance with the community rules. You can always contact us offline with any concerns you have
about moderation as well.<br>
This is a community where we all look after each member, so if you are worried about something that
you see on the forum, please report it. The report post/comment option simply sends your concern to
our moderators along with the post/comment. It helps us keeping the environment safe and welcoming
for our user community.<br><br>
<b>Comment Policy</b><br>
After submitting your comment on any post, your comment goes to the moderators of this platform to
review for things that you might have written against our community rules, specially around things that
users are not allowed to discuss here, such as medication names, ways of suicide or self harm, heavy
swear words, hate speech against a community/religion/gender/race etc.<br>
The following things must be kept in mind while posting comments:<br>
• Respect everyone in the community.<br>
• No external web-links in comments.<br>
• No use of hate speech against any race, religion, sexuality, nationality, sex, etc.<br>
• Keep the discussions cool, respect each others perspectives and thoughts.<br>
• No mentioning of names in comments/posts or usernames. comments with insulting names will
be discarded.<br>
• Please write relevant comments on the posts<br>
• Misbehavior against any other user will not be tolerated. most of the users are here to share their
story or to seek help or awareness on mental health. we should be respectful and constructive in
our comments.<br>
• No Duplicate comments<br>
• No mentioning of contact information or emails and phone numbers. If you need urgent help, feel
free to contact us through email/phone given on our contact-us page.<br>
• Moderators are the final judges whenever there is any violation regarding any rule regarding any
type of content/comment/post.<br><br>
This document was last updated on November 16, 2018
			</p><br><br><br><br>

		</div>
		<div class="col-md-1">
			<!-- Sidebar -->
		</div>
	</div>
</div>


<?php
// _________________________________FOOTER_______________________________
	include(BASE_URL.'/src/header/footer.php'); // Includes Script
// _________________________________FOOTER_______________________________
?>
