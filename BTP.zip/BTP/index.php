<?php
session_start();
//__________________________HEADER __________________________________________________________
define('BASE_URL', $_SERVER["DOCUMENT_ROOT"].'/BTP');
include(BASE_URL.'/src/header/header.php'); // INCLUDE HEADER FILE
//____________________________HEADER_________________________________________________________
?>

<div class="container-fluid" style="margin-top:50px">
	<h1>Mental Health : Forum , Feed and Statistics</h1><br>
	<div class="row">
		<div class="col-md-1">
			<!-- Sidebar -->
		</div>
		<div class="col-md-10">
			<h3>Developer: Neelesh Singh Rajpurohit</h3>

		</div>
		<div class="col-md-1">
			<!-- Sidebar -->
		</div>
	</div>
</div>


<?php
// _________________________________FOOTER_______________________________
	include(BASE_URL.'/src/header/footer.php'); // Includes Script
// _________________________________FOOTER_______________________________
?>
