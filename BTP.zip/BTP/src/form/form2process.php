<?php
//session_start(); 
$error=NULL;
$formid ="2";  // STRESS

$userid = $_SESSION['user_id'];

// DATABASE  SE KARO CONNECT BHAIYAJI...
	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}

if (isset($_POST['submit'])) {
		$ques1=$_POST['ques1'];
		$ques2=$_POST['ques2'];
		$ques3=$_POST['ques3'];
		$ques4=$_POST['ques4'];
		$ques5=$_POST['ques5'];
		$ques6=$_POST['ques6'];
		$ques7=$_POST['ques7'];
		$ques8=$_POST['ques8'];
		$ques9=$_POST['ques9'];
		$ques10=$_POST['ques10'];
		$ques11=$_POST['ques11'];
		$ques12=$_POST['ques12'];
		$ques13=$_POST['ques13'];
		$ques14=$_POST['ques14'];
		$ques15=$_POST['ques15'];
		$ques16=$_POST['ques16'];


	if (empty($_POST['ques1']) || empty($_POST['ques2'])|| empty($_POST['ques3'])|| empty($_POST['ques4'])|| empty($_POST['ques5'])|| empty($_POST['ques6'])|| empty($_POST['ques7'])|| empty($_POST['ques8'])|| empty($_POST['ques9'])|| empty($_POST['ques10'])|| empty($_POST['ques11'])|| empty($_POST['ques12'])|| empty($_POST['ques13'])|| empty($_POST['ques14'])|| empty($_POST['ques15'])|| empty($_POST['ques16'])) {
		$error = " Invalid Request ";
	}
	else{
	
		

		// Numerical Result
		$sum = $ques1+$ques2+$ques3+$ques4+$ques5+$ques6+$ques7+$ques8+$ques9+$ques10+$ques11+$ques12+$ques13+$ques14+$ques15+$ques16;
		//Conditional Results
		$sum=$sum-16;

		if($sum<=14){
			$result=1;
		}else if ($sum<=18) {
			$result=2;
		}else if ($sum<=25) {
			$result=3;
		}else if ($sum<=33) {
			$result=4;
		}else if ($sum<=48) {
			$result=5;
		}



		$sql = "select * from form where user_id = ".$userid." and form_id =".$formid."";
		$resultsql = mysqli_query($conn, $sql);

		if ($resultsql->num_rows == 0) {
			// no previous entry...
			$sql2 = "insert into form (user_id,form_id,result_id,result_sum)
					VALUES (".$userid.",".$formid.", ".$result.",".$sum.")";
		}else{
			// previous entry found....
			$sql2 = "UPDATE form SET result_id='".$result."', result_sum='".$sum."' where user_id=".$userid." and form_id =".$formid."";
		}

		if (mysqli_query($conn, $sql2)) {
			//goto results page
			header("location: /BTP/src/form/result.php");
		}else{
			$error = "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
	}
}

mysqli_close($conn); // Closing Connection

?>
