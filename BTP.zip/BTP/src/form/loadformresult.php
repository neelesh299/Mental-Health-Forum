<?php

$userid = $_SESSION['user_id'];

// DATABASE  SE KARO CONNECT BHAIYAJI...
	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}

	$sql = "select * from form where user_id = ".$userid."";
	$resultsql = mysqli_query($conn, $sql);

	$no_of_results = $resultsql->num_rows;

	for($j=1;$j<=$no_of_results;$j++){

		$row = $resultsql->fetch_assoc();

		$form[$j] = $row['form_id'];

		$result_id[$j] = $row['result_id'];

		$sum[$j] = $row['result_sum'];
		//Processing Data for each iteration

		if($form[$j]==1){
			$form[$j] = "Depression";

			if($result_id[$j]==1){
				$result_id[$j] = "These ups and downs are considered normal";
			}else if($result_id[$j]==2){
				$result_id[$j] = "Mild mood disturbances";
			}else if($result_id[$j]==3){
				$result_id[$j] = "Borderline Clinical Depression";
			}else if($result_id[$j]==4){
				$result_id[$j] = "Moderate Depression";
			}else if($result_id[$j]==5){
				$result_id[$j] = "Severe Depression";
			}else if($result_id[$j]==6){
				$result_id[$j] = "Extreme Depression";
			}

			$desc[$j] = "A score of 17 or more indicates you may need to seek professional help. If you are concerned in any way about your results you should contact us.";

		}else if($form[$j]==2){
			$form[$j] = "Stress";

			if($result_id[$j]==1){
				$result_id[$j] = "Low to Mild levels of Stress";
				$desc[$j] = "Stress is a normal reaction to circumstances in our everyday life. The results that you recorded suggest that you could be experiencing some stressful times in your life.";
			}else if($result_id[$j]==2){
				$result_id[$j] = "Mild Stress";
				$desc[$j] = "Whilst stress is a normal reaction to everyday circumstances, the results you have recorded suggest that you could be experiencing some signs of stress.";
			}else if($result_id[$j]==3){
				$result_id[$j] = "Moderate Stress";
				$desc[$j] = "The results that you recorded suggest that you are experiencing some significantly stressful events in your life. Whilst we all feel stressed at times, if stress goes on for too long or if the symptoms become severe then it can lead to other, more serious conditions.";
			}else if($result_id[$j]==4){
				$result_id[$j] = "Severe Stress";
				$desc[$j] = "From the answers you gave, it appears you are experiencing high levels of stress. We would always suggest seeking expert help and support as, left untreated, stress can become worse and lead to mental health conditions such as Anxiety or Depression.";
			}else if($result_id[$j]==5){
				$result_id[$j] = "Extremely Severe Stress";
				$desc[$j] = "You have reported that you are experiencing very high levels of stress which may be having a significant impact on your mental health and ability to enjoy life. Whilst some stress is normal, the high levels that you report can be an indicator of something more severe. Left untreated and unmanaged, experiencing such high levels of stress can place you at higher risk of developing both mental and physical illness.";
			}

		}else if($form[$j]==3){
			$form[$j] = "Anxiety";

			if($result_id[$j]==1){
				$result_id[$j] = "Unlikely ";
				$desc[$j] = "The answers you have given to this test suggest that you are not suffering with an anxiety disorder. However, the test only looks at some of the most common symptoms and some anxiety disorders, such as OCD, have specific symptoms that are not covered here.";
			}else if($result_id[$j]==2){
				$result_id[$j] = "May be suffering ";
				$desc[$j] = "The answers you have given to this test indicate that you may be suffering with an anxiety disorder and you are experiencing many of the most common symptoms. It is important to note that struggling with these symptoms does not necessarily mean you have an anxiety disorder; sometimes other medical conditions can result in these signs and for that reason we would always urge you to seek medical help to rule out any other conditions that could be causing these symptoms.";
			}else if($result_id[$j]==3){
				$result_id[$j] = "Likely ";
				$desc[$j] = "The answers you have given to this test suggest that you are likely to be suffering with an anxiety disorder and would benefit from seeking professional help. Anxiety disorders can be very difficult to live with; Please consult professional medical Help.";
			}

		}

		}// end of for loop


mysqli_close($conn); // Closing Connection

?>
