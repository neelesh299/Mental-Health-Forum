
<?php
session_start();
include('form3process.php'); // Includes Form Script
//__________________________HEADER __________________________________________________________
define('BASE_URL', $_SERVER["DOCUMENT_ROOT"].'/BTP');
include(BASE_URL.'/src/header/header.php'); // INCLUDE HEADER FILE
//____________________________HEADER_________________________________________________________

	if(isset($_SESSION['login_user'])){
		;
	}
	else{
		header("location: /BTP/src/user/login_form.php");
	}

?>

<div class="container-fluid" style="margin-top:50px">
	<div class="row">
		<div class="col-md-2 sidenav ">
			<!-- Sidebar -->
			<h4>Happinezz</h4>
      <ul class="nav nav-pills nav-stacked">
        <li><a href="http://localhost/BTP/src/user/profile.php">Dashboard</a></li>
        <li><a href="http://localhost/BTP/src/user/update_profile.php">Update Profile</a></li>
        <li><a href="http://localhost/BTP/src/account_recovery/account_settings.php">Account Settings</a></li>
        <li><a href="http://localhost/BTP/src/blog/stories.php">Stories</a></li>
        <li><a href="http://localhost/BTP/src/comments/reviewcomments.php">Comments</a></li>
        <li class="active"><a href="http://localhost/BTP/src/form/loadforms.php">Psych-Tests</a></li>
        <li><a href="http://localhost/BTP/src/user/community.php">Community</a></li>
        <?php if($_SESSION['user_level']==5) { ?> 
        <li><a href="http://localhost/BTP/src/admin/view_logs.php">View Logs</a></li>
      	<li><a href="http://localhost/BTP/src/admin/manage_users.php">Manage Users</a></li>
        <li><a href="http://localhost/BTP/src/report/viewreports.php">Complaints</a></li>
        <li><a href="http://localhost/BTP/src/admin/view_form_response.php">User Reports</a></li>
        <?php } ?>
      </ul><br>
		</div>
		<div class="col-md-2">
		</div>
		<div class="col-md-10">	
			<h1><a>Anxiety Test</a>&nbsp;&nbsp;<a class="btn btn-primary" href="/BTP/src/form/loadforms.php"> Back</a></h1><br>
			<p>When answering the above questions please consider how they have applied to you in the last month or so. This test will give an indication as to whether you are experiencing the most common symptoms of an anxiety disorder, but it cannot replace a full assessment nor should be used to self diagnose or decide upon a treatment plan.</p>

			<p><b>If you are at all concerned about the results we would recommend you seeking professional help as soon as possible. You can call and discuss your results with our team on 99999 99999 or mental_health@gmail.com</b></p>

			<p>Answer the following questions:</p>

			<!-- Show Previous Results (if any)-->

			<!-- Start Form Below -->
			<form name="form1" class="form-horizontal" action="" method="POST">
				
				<div class="form-group">
					<label class="control-label col-sm-4">1. I find it very hard to unwind, relax or sit still</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques1">
							<option value="">Choose</option>
							<option value="1">Never</option>
							<option value="2">Rarely</option>
							<option value="3">Sometimes</option>
							<option value="4">Often</option>
							<option value="5">Very often</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">2. I have had stomach problems, such as feeling sick or stomach cramps</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques2">
							<option value="">Choose</option>
							<option value="1">Never</option>
							<option value="2">Rarely</option>
							<option value="3">Sometimes</option>
							<option value="4">Often</option>
							<option value="5">Very often</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">3. I have been irritable and easily become annoyed</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques3">
							<option value="">Choose</option>
							<option value="1">Never</option>
							<option value="2">Rarely</option>
							<option value="3">Sometimes</option>
							<option value="4">Often</option>
							<option value="5">Very often</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">4. I have experienced shortness of breath</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques4">
							<option value="">Choose</option>
							<option value="1">Never</option>
							<option value="2">Rarely</option>
							<option value="3">Sometimes</option>
							<option value="4">Often</option>
							<option value="5">Very often</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">5. I have felt dizzy and unsteady at times</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques5">
							<option value="">Choose</option>
							<option value="1">Never</option>
							<option value="2">Rarely</option>
							<option value="3">Sometimes</option>
							<option value="4">Often</option>
							<option value="5">Very often</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">6. I have had difficulties with sleep (including waking early, finding it hard to go to sleep)</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques6">
							<option value="">Choose</option>
							<option value="1">Never</option>
							<option value="2">Rarely</option>
							<option value="3">Sometimes</option>
							<option value="4">Often</option>
							<option value="5">Very often</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">7. I have felt panicked and overwhelmed by things in my life</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques7">
							<option value="">Choose</option>
							<option value="1">Never</option>
							<option value="2">Rarely</option>
							<option value="3">Sometimes</option>
							<option value="4">Often</option>
							<option value="5">Very often</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">8. I have felt nervous and on edge</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques8">
							<option value="">Choose</option>
							<option value="1">Never</option>
							<option value="2">Rarely</option>
							<option value="3">Sometimes</option>
							<option value="4">Often</option>
							<option value="5">Very often</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">9. I have had trembling hands</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques9">
							<option value="">Choose</option>
							<option value="1">Never</option>
							<option value="2">Rarely</option>
							<option value="3">Sometimes</option>
							<option value="4">Often</option>
							<option value="5">Very often</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">10. I seem to be constantly worrying about things</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques10">
							<option value="">Choose</option>
							<option value="1">Never</option>
							<option value="2">Rarely</option>
							<option value="3">Sometimes</option>
							<option value="4">Often</option>
							<option value="5">Very often</option>
						</select>
					</div>
				</div>

				

				<div class="form-group">
    				<div class="col-sm-offset-4 col-sm-6">
						
						<!-- .......................................................... -->
						<?php if($error==NULL) {?>
						<div> 
							<?php } else {?>
						<div style="margin-top: 5px;" class="alert alert-danger alert-dismissible in">
							<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							<?php } ?>
						<?php echo $error; ?>
						</div>
						<!-- .......................................................... -->
						<input style="width=100%;" class="btn btn-success" name="submit" type="submit" value=" Submit Response ">
						&nbsp;&nbsp;<a class="btn btn-primary" href="/BTP/src/form/loadforms.php"> Back</a><br><br>
					</div>
				</div>	


			</form>
		</div>
	</div>
</div>


<?php
// _________________________________FOOTER_______________________________
	include(BASE_URL.'/src/header/footer.php'); // Includes Script
// _________________________________FOOTER_______________________________
?>
