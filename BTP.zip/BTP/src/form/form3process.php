<?php
//session_start(); 
$error=NULL;
$formid ="3";  // ANXIETY

$userid = $_SESSION['user_id'];

// DATABASE  SE KARO CONNECT BHAIYAJI...
	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}

if (isset($_POST['submit'])) {
		$ques1=$_POST['ques1'];
		$ques2=$_POST['ques2'];
		$ques3=$_POST['ques3'];
		$ques4=$_POST['ques4'];
		$ques5=$_POST['ques5'];
		$ques6=$_POST['ques6'];
		$ques7=$_POST['ques7'];
		$ques8=$_POST['ques8'];
		$ques9=$_POST['ques9'];
		$ques10=$_POST['ques10'];


	if (empty($_POST['ques1']) || empty($_POST['ques2'])|| empty($_POST['ques3'])|| empty($_POST['ques4'])|| empty($_POST['ques5'])|| empty($_POST['ques6'])|| empty($_POST['ques7'])|| empty($_POST['ques8'])|| empty($_POST['ques9'])|| empty($_POST['ques10'])) {
		$error = " Invalid Request ";
	}
	else{
	
		

		// Numerical Result
		$sum = $ques1+$ques2+$ques3+$ques4+$ques5+$ques6+$ques7+$ques8+$ques9+$ques10;
		//Conditional Results
		$sum=$sum-10;

		if($sum<=10){
			$result=1;
		}else if ($sum<=26) {
			$result=2;
		}else if ($sum<=40) {
			$result=3;
		}



		$sql = "select * from form where user_id = ".$userid." and form_id =".$formid."";
		$resultsql = mysqli_query($conn, $sql);

		if ($resultsql->num_rows == 0) {
			// no previous entry...
			$sql2 = "insert into form (user_id,form_id,result_id,result_sum)
					VALUES (".$userid.",".$formid.", ".$result.",".$sum.")";
		}else{
			// previous entry found....
			$sql2 = "UPDATE form SET result_id='".$result."', result_sum='".$sum."' where user_id=".$userid." and form_id =".$formid."";
		}

		if (mysqli_query($conn, $sql2)) {
			//goto results page
			header("location: /BTP/src/form/result.php");
		}else{
			$error = "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
	}
}

mysqli_close($conn); // Closing Connection

?>
