
<?php
session_start();
include('form1process.php'); // Includes Form Script
//__________________________HEADER __________________________________________________________
define('BASE_URL', $_SERVER["DOCUMENT_ROOT"].'/BTP');
include(BASE_URL.'/src/header/header.php'); // INCLUDE HEADER FILE
//____________________________HEADER_________________________________________________________

	if(isset($_SESSION['login_user'])){
		;
	}
	else{
		header("location: /BTP/src/user/login_form.php");
	}

?>

<div class="container-fluid" style="margin-top:50px">
	<div class="row">
		<div class="col-md-2 sidenav ">
			<!-- Sidebar -->
			<h4>Happinezz</h4>
      <ul class="nav nav-pills nav-stacked">
        <li><a href="http://localhost/BTP/src/user/profile.php">Dashboard</a></li>
        <li><a href="http://localhost/BTP/src/user/update_profile.php">Update Profile</a></li>
        <li><a href="http://localhost/BTP/src/account_recovery/account_settings.php">Account Settings</a></li>
        <li><a href="http://localhost/BTP/src/blog/stories.php">Stories</a></li>
        <li><a href="http://localhost/BTP/src/comments/reviewcomments.php">Comments</a></li>
        <li class="active"><a href="http://localhost/BTP/src/form/loadforms.php">Psych-Tests</a></li>
        <li><a href="http://localhost/BTP/src/user/community.php">Community</a></li>
        <?php if($_SESSION['user_level']==5) { ?> 
        <li><a href="http://localhost/BTP/src/admin/view_logs.php">View Logs</a></li>
      	<li><a href="http://localhost/BTP/src/admin/manage_users.php">Manage Users</a></li>
        <li><a href="http://localhost/BTP/src/report/viewreports.php">Complaints</a></li>
        <li><a href="http://localhost/BTP/src/admin/view_form_response.php">User Reports</a></li>
        <?php } ?>
      </ul><br>
		</div>
		<div class="col-md-2">
		</div>
		<div class="col-md-10">	
			<h1><a>Depression Test</a>&nbsp;&nbsp;<a class="btn btn-primary" href="/BTP/src/form/loadforms.php"> Back</a></h1><br>
			<p>The following questions will help identify if you might be suffering from depression; the test is an indicator only and not meant to replace a full assessment by a qualified clinician. When completing the following questions it is useful to think about how they have applied to you over the last few weeks or months.</p>

			<p><b>If you are at all concerned about the results we would recommend you seeking professional help as soon as possible. You can call and discuss your results with our team on 99999 99999 or mental_health@gmail.com</b></p>

			<p>Answer the following questions:</p>

			<!-- Show Previous Results (if any)-->

			<!-- Start Form Below -->
			<form name="form1" class="form-horizontal" action="" method="POST">
				
				<div class="form-group">
					<label class="control-label col-sm-4">1. Which describes you best?</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques1">
							<option value="">Choose</option>
							<option value="1">I do not feel sad</option>
							<option value="2">I feel sad</option>
							<option value="3">I am sad all the time and I can't snap out of it</option>
							<option value="4">I am so sad and unhappy that I can't stand it</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">2. Which describes you best? </label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques2">
							<option value="">Choose</option>
							<option value="1">I am not particularly discouraged about the future</option>
							<option value="2">I feel discouraged about the future</option>
							<option value="3">I feel I have nothing to look forward to</option>
							<option value="4">I feel the future is hopeless and that things cannot improve</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">3. Which describes you best?</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques3">
							<option value="">Choose</option>
							<option value="1">I do not feel like a failure</option>
							<option value="2">I feel I have failed more than the average person</option>
							<option value="3">As I look back on my life, all I can see is a lot of failures</option>
							<option value="4">I feel I am a complete failure as a person</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">4. Which describes you best?</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques4">
							<option value="">Choose</option>
							<option value="1">I get as much satisfaction out of things as I used to</option>
							<option value="2">I don't enjoy things the way I used to</option>
							<option value="3">I don't get real satisfaction out of anything anymore</option>
							<option value="4">I am dissatisfied or bored with everything</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">5. Which describes you best?</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques5">
							<option value="">Choose</option>
							<option value="1">I don't feel particularly guilty</option>
							<option value="2">I feel guilty a good part of the time</option>
							<option value="3">I feel quite guilty most of the time</option>
							<option value="4">I feel guilty all of the time</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">6. Which describes you best?</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques6">
							<option value="">Choose</option>
							<option value="1">I don't feel I am being punished</option>
							<option value="2">I feel I may be punished</option>
							<option value="3">I expect to be punished</option>
							<option value="4">I feel I am being punished</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">7. Which describes you best?</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques7">
							<option value="">Choose</option>
							<option value="1">I don't feel disappointed in myself</option>
							<option value="2">I am disappointed in myself</option>
							<option value="3">I am disgusted with myself</option>
							<option value="4">I hate myself</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">8. Which describes you best?</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques8">
							<option value="">Choose</option>
							<option value="1">I don't feel I am any worse than anybody else</option>
							<option value="2">I am critical of myself for my weaknesses or mistakes</option>
							<option value="3">I blame myself all the time for my faults</option>
							<option value="4">I blame myself for everything bad that happens</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">9. Which describes you best?</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques9">
							<option value="">Choose</option>
							<option value="1">I don't have any thoughts of killing myself</option>
							<option value="2">I have thoughts of killing myself, but I would not carry them out</option>
							<option value="3">I would like to kill myself</option>
							<option value="4">I would kill myself if I had the chance</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">10. Which describes you best?</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques10">
							<option value="">Choose</option>
							<option value="1">I don't cry any more than usual</option>
							<option value="2">I cry more now than I used to</option>
							<option value="3">I cry all the time now</option>
							<option value="4">I used to be able to cry, but now I can't cry even though I want to</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">11. Which describes you best?</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques11">
							<option value="">Choose</option>
							<option value="1">I am no more irritated by things than I ever was</option>
							<option value="2">I am slightly more irritated now than usual</option>
							<option value="3">I am quite annoyed or irritated a good deal of the time</option>
							<option value="4">I feel irritated all the time</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">12. Which describes you best?</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques12">
							<option value="">Choose</option>
							<option value="1">I have not lost interest in other people</option>
							<option value="2">I am less interested in other people than I used to be</option>
							<option value="3">I have lost most of my interest in other people</option>
							<option value="4">I have lost all of my interest in other people</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">13. Which describes you best?</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques13">
							<option value="">Choose</option>
							<option value="1">I make decisions about as well as I ever could</option>
							<option value="2">I put off making decisions more than I used to</option>
							<option value="3">I have greater difficulty in making decisions more than I used to</option>
							<option value="4">I can't make decisions at all anymore</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">14. Which describes you best?</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques14">
							<option value="">Choose</option>
							<option value="1">I don't feel that I look any worse than I used to</option>
							<option value="2">I am worried that I am looking old or unattractive</option>
							<option value="3">I feel there are permanent changes in my appearance that make me look unattractive</option>
							<option value="4">I believe that I look ugly</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">15. Which describes you best?</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques15">
							<option value="">Choose</option>
							<option value="1">I can work about as well as before</option>
							<option value="2">It takes an extra effort to get started at doing something</option>
							<option value="3">I have to push myself very hard to do anything</option>
							<option value="4">I can't do any work at all</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">16. Which describes you best?</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques16">
							<option value="">Choose</option>
							<option value="1">I can sleep as well as usual</option>
							<option value="2">I don't sleep as well as I used to</option>
							<option value="3">I wake up 1-2 hours earlier than usual and find it hard to get back to sleep</option>
							<option value="4">I wake up several hours earlier than I used to and cannot get back to sleep</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">17. Which describes you best?</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques17">
							<option value="">Choose</option>
							<option value="1">I don't get more tired than usual</option>
							<option value="2">I get tired more easily than I used to</option>
							<option value="3">I get tired from doing almost anything</option>
							<option value="4">I am too tired to do anything</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">18. Which describes you best?</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques18">
							<option value="">Choose</option>
							<option value="1">My appetite is no worse than usual</option>
							<option value="2">My appetite is not as good as it used to be</option>
							<option value="3">My appetite is much worse now</option>
							<option value="4">I have no appetite at all anymore</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">19. Which describes you best?</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques19">
							<option value="">Choose</option>
							<option value="1">I haven't lost much weight, if any, lately</option>
							<option value="2">I have lost more than five pounds</option>
							<option value="3">I have lost more than ten pounds</option>
							<option value="4">I have lost more than fifteen pounds</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">20. Which describes you best?</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques20">
							<option value="">Choose</option>
							<option value="1">I am no more worried about my health than usual</option>
							<option value="2">I am worried about physical problems like aches, pains, upset stomach, or constipation</option>
							<option value="3">I am very worried about physical problems and it's hard to think of much else</option>
							<option value="4">I am so worried about my physical problems that I cannot think of anything else</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">21. Which describes you best?</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques21">
							<option value="">Choose</option>
							<option value="1">I have not noticed any recent change in my interest in sex</option>
							<option value="2">I am less interested in sex than I used to be</option>
							<option value="3">I have almost no interest in sex</option>
							<option value="4">I have lost interest in sex completely</option>
						</select>
					</div>
				</div>
				<div class="form-group">
    				<div class="col-sm-offset-4 col-sm-6">
						
						<!-- .......................................................... -->
						<?php if($error==NULL) {?>
						<div> 
							<?php } else {?>
						<div style="margin-top: 5px;" class="alert alert-danger alert-dismissible in">
							<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							<?php } ?>
						<?php echo $error; ?>
						</div>
						<!-- .......................................................... -->
						<input style="width=100%;" class="btn btn-success" name="submit" type="submit" value=" Submit Response ">
						&nbsp;&nbsp;<a class="btn btn-primary" href="/BTP/src/form/loadforms.php"> Back</a><br><br>
					</div>
				</div>	


			</form>
		</div>
	</div>
</div>


<?php
// _________________________________FOOTER_______________________________
	include(BASE_URL.'/src/header/footer.php'); // Includes Script
// _________________________________FOOTER_______________________________
?>
