
<?php
session_start();
include('form2process.php'); // Includes Form Script
//__________________________HEADER __________________________________________________________
define('BASE_URL', $_SERVER["DOCUMENT_ROOT"].'/BTP');
include(BASE_URL.'/src/header/header.php'); // INCLUDE HEADER FILE
//____________________________HEADER_________________________________________________________

	if(isset($_SESSION['login_user'])){
		;
	}
	else{
		header("location: /BTP/src/user/login_form.php");
	}

?>

<div class="container-fluid" style="margin-top:50px">
	<div class="row">
		<div class="col-md-2 sidenav ">
			<!-- Sidebar -->
			<h4>Happinezz</h4>
      <ul class="nav nav-pills nav-stacked">
        <li><a href="http://localhost/BTP/src/user/profile.php">Dashboard</a></li>
        <li><a href="http://localhost/BTP/src/user/update_profile.php">Update Profile</a></li>
        <li><a href="http://localhost/BTP/src/account_recovery/account_settings.php">Account Settings</a></li>
        <li><a href="http://localhost/BTP/src/blog/stories.php">Stories</a></li>
        <li><a href="http://localhost/BTP/src/comments/reviewcomments.php">Comments</a></li>
        <li class="active"><a href="http://localhost/BTP/src/form/loadforms.php">Psych-Tests</a></li>
        <li><a href="http://localhost/BTP/src/user/community.php">Community</a></li>
        <?php if($_SESSION['user_level']==5) { ?> 
        <li><a href="http://localhost/BTP/src/admin/view_logs.php">View Logs</a></li>
      	<li><a href="http://localhost/BTP/src/admin/manage_users.php">Manage Users</a></li>
        <li><a href="http://localhost/BTP/src/report/viewreports.php">Complaints</a></li>
        <li><a href="http://localhost/BTP/src/admin/view_form_response.php">User Reports</a></li>
        <?php } ?>
      </ul><br>
		</div>
		<div class="col-md-2">
		</div>
		<div class="col-md-10">	
			<h1><a>Stress Test</a>&nbsp;&nbsp;<a class="btn btn-primary" href="/BTP/src/form/loadforms.php"> Back</a></h1><br>
			<p>When answering the following questions please consider how they have applied to you in the last 2-3 weeks. The above questions may help identify if you are suffering with stress and to what degree. It is not meant to replace a full assessment by a qualified clinician.</p>

			<p><b>If you are at all concerned about the results we would recommend you seeking professional help as soon as possible. You can call and discuss your results with our team on 99999 99999 or mental_health@gmail.com</b></p>

			<p>Answer the following questions:</p>

			<!-- Show Previous Results (if any)-->

			<!-- Start Form Below -->
			<form name="form1" class="form-horizontal" action="" method="POST">
				
				<div class="form-group">
					<label class="control-label col-sm-4">1. I have found myself getting upset by quite trivial things</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques1">
							<option value="">Choose</option>
							<option value="1">Not at all</option>
							<option value="2">Ocassionally</option>
							<option value="3">Often</option>
							<option value="4">Very much so</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">2. I have been aware of dryness of my mouth</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques2">
							<option value="">Choose</option>
							<option value="1">Not at all</option>
							<option value="2">Ocassionally</option>
							<option value="3">Often</option>
							<option value="4">Very much so</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">3. I have experienced breathing difficulties</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques3">
							<option value="">Choose</option>
							<option value="1">Not at all</option>
							<option value="2">Ocassionally</option>
							<option value="3">Often</option>
							<option value="4">Very much so</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">4. I have tended to overreact to situations</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques4">
							<option value="">Choose</option>
							<option value="1">Not at all</option>
							<option value="2">Ocassionally</option>
							<option value="3">Often</option>
							<option value="4">Very much so</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">5. I have felt shakey – like my legs are going to give way</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques5">
							<option value="">Choose</option>
							<option value="1">Not at all</option>
							<option value="2">Ocassionally</option>
							<option value="3">Often</option>
							<option value="4">Very much so</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">6. I have found myself getting upset easily</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques6">
							<option value="">Choose</option>
							<option value="1">Not at all</option>
							<option value="2">Ocassionally</option>
							<option value="3">Often</option>
							<option value="4">Very much so</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">7. I have found myself getting impatient when I have been delayed in any way</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques7">
							<option value="">Choose</option>
							<option value="1">Not at all</option>
							<option value="2">Ocassionally</option>
							<option value="3">Often</option>
							<option value="4">Very much so</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">8. I have experienced sweaty palms or perspiration for no physical reasons</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques8">
							<option value="">Choose</option>
							<option value="1">Not at all</option>
							<option value="2">Ocassionally</option>
							<option value="3">Often</option>
							<option value="4">Very much so</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">9. I have felt scared or nervous for no good reason</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques9">
							<option value="">Choose</option>
							<option value="1">Not at all</option>
							<option value="2">Ocassionally</option>
							<option value="3">Often</option>
							<option value="4">Very much so</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">10.I have been aware of my heart rate, even when I am not exercising</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques10">
							<option value="">Choose</option>
							<option value="1">Not at all</option>
							<option value="2">Ocassionally</option>
							<option value="3">Often</option>
							<option value="4">Very much so</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">11. I have had a sense of nervous tension – like being on edge all the time</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques11">
							<option value="">Choose</option>
							<option value="1">Not at all</option>
							<option value="2">Ocassionally</option>
							<option value="3">Often</option>
							<option value="4">Very much so</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">12. I have been very irritable</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques12">
							<option value="">Choose</option>
							<option value="1">Not at all</option>
							<option value="2">Ocassionally</option>
							<option value="3">Often</option>
							<option value="4">Very much so</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">13. I have been close to panic</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques13">
							<option value="">Choose</option>
							<option value="1">Not at all</option>
							<option value="2">Ocassionally</option>
							<option value="3">Often</option>
							<option value="4">Very much so</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">14. I have found it hard to calm down after something has upset me</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques14">
							<option value="">Choose</option>
							<option value="1">Not at all</option>
							<option value="2">Ocassionally</option>
							<option value="3">Often</option>
							<option value="4">Very much so</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">15. It has been difficult for me to tolerate interruptions to what I was doing</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques15">
							<option value="">Choose</option>
							<option value="1">Not at all</option>
							<option value="2">Ocassionally</option>
							<option value="3">Often</option>
							<option value="4">Very much so</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-4">16. I am worried I will panic and make a fool of myself</label>
					<div class="col-sm-6">
						<select required class="form-control" name="ques16">
							<option value="">Choose</option>
							<option value="1">Not at all</option>
							<option value="2">Ocassionally</option>
							<option value="3">Often</option>
							<option value="4">Very much so</option>
						</select>
					</div>
				</div>

				<div class="form-group">
    				<div class="col-sm-offset-4 col-sm-6">
						
						<!-- .......................................................... -->
						<?php if($error==NULL) {?>
						<div> 
							<?php } else {?>
						<div style="margin-top: 5px;" class="alert alert-danger alert-dismissible in">
							<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							<?php } ?>
						<?php echo $error; ?>
						</div>
						<!-- .......................................................... -->
						<input style="width=100%;" class="btn btn-success" name="submit" type="submit" value=" Submit Response ">
						&nbsp;&nbsp;<a class="btn btn-primary" href="/BTP/src/form/loadforms.php"> Back</a><br><br>
					</div>
				</div>	


			</form>
		</div>
	</div>
</div>


<?php
// _________________________________FOOTER_______________________________
	include(BASE_URL.'/src/header/footer.php'); // Includes Script
// _________________________________FOOTER_______________________________
?>
