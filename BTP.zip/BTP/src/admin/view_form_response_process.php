<?php

	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}

	$test[1]="Depression";
	$test[3]="Anxiety";
	$test[2]="Stress";

	$num[1]=0;
	$num[2]=0;
	$num[3]=0;

	$score[1]=0;
	$score[2]=0;
	$score[3]=0;

	$depcat[1]="Normal";
	$depcat[2]="Mild mood disturbances";
	$depcat[3]="Borderline Clinical Depression";
	$depcat[4]="Moderate Depression";
	$depcat[5]="Severe Depression";
	$depcat[6]="Extreme Depression";

	$depnum[1]=0;
	$depnum[2]=0;
	$depnum[3]=0;
	$depnum[4]=0;
	$depnum[5]=0;
	$depnum[6]=0;

	$strcat[1]="Low to Mild levels of Stress";
	$strcat[2]="Mild Stress";
	$strcat[3]="Moderate Stress";
	$strcat[4]="Severe Stress";
	$strcat[5]="Extremely Severe Stress";

	$strnum[1]=0;
	$strnum[2]=0;
	$strnum[3]=0;
	$strnum[4]=0;
	$strnum[5]=0;

	$anxcat[1]="Unlikely";
	$anxcat[2]="May be suffering";
	$anxcat[3]="Likely";

	$anxnum[1]=0;
	$anxnum[2]=0;
	$anxnum[3]=0;


	$sql = "SELECT * FROM form";

	$result2 = mysqli_query($conn, $sql);

	$totalent = $result2->num_rows;
	for($i=1;$i<=$totalent;$i++){
		$row = $result2->fetch_assoc();

		$type= $row['form_id'];
		$result = $row['result_id'];

		if($type==1){
			$depnum[$result] = $depnum[$result] + 1;
		}else if($type==2){
			$strnum[$result] = $strnum[$result] + 1;
		}else if($type==3){
			$anxnum[$result] = $anxnum[$result] + 1;
		}

		$num[$type] = $num[$type] + 1;
		$score[$type] = $score[$type] + $row['result_sum'];
	}

	for($i=1;$i<=3;$i++){
		$score[$i] = $score[$i] / $num[$i];
	}

	// Calculating overall Health ...................................................................

	if($score[1]<=10){
		$health[1]="These ups and downs are considered normal";
	}else if($score[1]<=16){
		$health[1]="Mild mood disturbances";
	}else if($score[1]<=20){
		$health[1]="Borderline Clinical Depression";
	}else if($score[1]<=30){
		$health[1]="Moderate Depression";
	}else if($score[1]<=40){
		$health[1]="Severe Depression";
	}else if($score[1]>40){
		$health[1]="Extreme Depression";
	}

	if($score[2]<=14){
		$health[2]="Low to Mild levels of Stress";
	}else if($score[2]<=18){
		$health[2]="Mild Stress";
	}else if($score[2]<=25){
		$health[2]="Moderate Stress";
	}else if($score[2]<=33){
		$health[2]="Severe Stress";
	}else if($score[2]<=48){
		$health[2]="Extremely Severe Stress";
	}

	if($score[3]<=10){
		$health[3]="Unlikely";
	}else if($score[3]<=26){
		$health[3]="May be suffering";
	}else if($score[3]<=40){
		$health[3]="Likely";
	}

?>