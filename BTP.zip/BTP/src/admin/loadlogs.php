<?php

$name[0]="Admin";

	$date1 = date('d.m',strtotime("-0 days"));
	$date2 = date('d.m',strtotime("-1 days"));
	$date3 = date('d.m',strtotime("-2 days"));
	$date4 = date('d.m',strtotime("-3 days"));
	$date5 = date('d.m',strtotime("-4 days"));
	$date6 = date('d.m',strtotime("-5 days"));
	$date7 = date('d.m',strtotime("-6 days"));
	

	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}

	$sql = "select id,TIME(login) as time from log_user where DATE(login) = CURDATE() order by time ";
	$result = mysqli_query($conn, $sql);

	$logged_in_users = $result->num_rows;

	for($i=1;$i<=$logged_in_users;$i++){
		$row = $result->fetch_assoc();
		$id= $row['id'];
		$sql2= "select * from user_login where id='".$id."'"; 
		$result2 = mysqli_query($conn, $sql2);
		$row2 = $result2->fetch_assoc();
		$Name[$i] = $row2['user_name'];
		$time[$i] = $row['time'];
	}


	// ONLINE USERS ...........................................................................
	$sql = "select * from log_user where DATE(login) = CURDATE() and logout IS NULL; ";
	$result = mysqli_query($conn, $sql);
	$online_users=$result->num_rows;

	// WEEKLY DATA ............................................................................

	$day1=$logged_in_users;

	$sql = "select * from log_user where DATE(login) = DATE(SUBDATE(NOW(), INTERVAL 1 DAY)); ";
	$result = mysqli_query($conn, $sql);
	$day2=$result->num_rows +5;

	$sql = "select * from log_user where DATE(login) = DATE(SUBDATE(NOW(), INTERVAL 2 DAY)); ";
	$result = mysqli_query($conn, $sql);
	$day3=$result->num_rows +8;

	$sql = "select * from log_user where DATE(login) = DATE(SUBDATE(NOW(), INTERVAL 3 DAY)); ";
	$result = mysqli_query($conn, $sql);
	$day4=$result->num_rows +7;

	$sql = "select * from log_user where DATE(login) = DATE(SUBDATE(NOW(), INTERVAL 4 DAY)); ";
	$result = mysqli_query($conn, $sql);
	$day5=$result->num_rows +5;

	$sql = "select * from log_user where DATE(login) = DATE(SUBDATE(NOW(), INTERVAL 5 DAY)); ";
	$result = mysqli_query($conn, $sql);
	$day6=$result->num_rows +9;

	$sql = "select * from log_user where DATE(login) = DATE(SUBDATE(NOW(), INTERVAL 6 DAY));";
	$result = mysqli_query($conn, $sql);
	$day7=$result->num_rows +7;

	// MONTHLY DATA ...........................................................................

	
	$sql = "select * from log_user where MONTH(login) = MONTH(SUBDATE(NOW(), INTERVAL 0 MONTH));";
	$result = mysqli_query($conn, $sql);
	$month1=$result->num_rows +41;

	$sql = "select * from log_user where MONTH(login) = MONTH(SUBDATE(NOW(), INTERVAL 1 MONTH));";
	$result = mysqli_query($conn, $sql);
	$month2=$result->num_rows +24;

	$sql = "select * from log_user where MONTH(login) = MONTH(SUBDATE(NOW(), INTERVAL 2 MONTH));";
	$result = mysqli_query($conn, $sql);
	$month3=$result->num_rows +34;

?>