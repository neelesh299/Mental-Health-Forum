<?php
session_start();
//__________________________HEADER __________________________________________________________
define('BASE_URL', $_SERVER["DOCUMENT_ROOT"].'/BTP');
include(BASE_URL.'/src/header/header.php'); // INCLUDE HEADER FILE
//____________________________HEADER_________________________________________________________
include('loadlogs.php');

	if(isset($_SESSION['login_user'])){
		if($_SESSION['user_level']!=5){
			header("location: /BTP/src/user/profile.php");
		}
	}
	else{
		header("location: /BTP/src/user/login_form.php");
	}
?>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Date', 'Visitors'],
          ['<?php echo $date7; ?>', <?php echo $day7;?> ],
          ['<?php echo $date6; ?>', <?php echo $day6;?> ],
          ['<?php echo $date5; ?>', <?php echo $day5;?> ],
          ['<?php echo $date4; ?>', <?php echo $day4;?> ],
          ['<?php echo $date3; ?>', <?php echo $day3;?> ],
          ['<?php echo $date2; ?>', <?php echo $day2;?> ],
          ['<?php echo $date1; ?>', <?php echo $day1;?> ],
        ]);

        var options = {
          chart: {
            title: 'Login stats this Week',
          },
          bars: 'vertical' // Required for Material Bar Charts.
        };

        var chart = new google.charts.Bar(document.getElementById('barchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script>


<div class="container-fluid" style="margin-top:50px">
  <div class="row">
    <div class="col-md-2 sidenav ">
      <!-- Sidebar -->
      <h4>Happinezz</h4>
      <ul class="nav nav-pills nav-stacked">
        <li><a href="http://localhost/BTP/src/user/profile.php">Dashboard</a></li>
        <li><a href="http://localhost/BTP/src/user/update_profile.php">Update Profile</a></li>
        <li><a href="http://localhost/BTP/src/account_recovery/account_settings.php">Account Settings</a></li>
        <li><a href="http://localhost/BTP/src/blog/stories.php">Stories</a></li>
        <li><a href="http://localhost/BTP/src/comments/reviewcomments.php">Comments</a></li>
        <li><a href="http://localhost/BTP/src/form/loadforms.php">Psych-Tests</a></li>
        <li><a href="http://localhost/BTP/src/user/community.php">Community</a></li>
        <?php if($_SESSION['user_level']==5) { ?> 
        <li class="active"><a href="http://localhost/BTP/src/admin/view_logs.php">View Logs</a></li>
        <li><a href="http://localhost/BTP/src/admin/manage_users.php">Manage Users</a></li>
        <li><a href="http://localhost/BTP/src/report/viewreports.php">Complaints</a></li>
        <li><a href="http://localhost/BTP/src/admin/view_form_response.php">User Reports</a></li>
        <?php } ?>
      </ul><br>
    </div>
    <div class="col-md-2">
    </div>
    <div class="col-md-4"> 
        <h2> Logs </h2>
        <br>
        <h5>Number of Users Online: <span class="bg-info">&nbsp;<?php echo $online_users; ?>&nbsp;</span></h5>
        <hr>
        <h5>Number of User Login Count Today: <span class="bg-info">&nbsp;<?php echo $logged_in_users; ?>&nbsp;</span></h5>
        <hr>
        <div id="barchart_material" style="width: 400px; height: 200px;"></div>
        <hr>
        <h5> Login Stats for past Months: <span class="bg-info">&nbsp;<?php echo $month3." - ".$month2." - ".$month1; ?></span></h5>
    </div>
    <div class="col-md-6"> 
      <h2><a class="btn btn-primary pull-right" href="/BTP/src/admin/view_logs.php">Refresh Data</a></h2>
      <br>
      <h5>Todays Logs for User Logins:</h5>
      <div class="table-responsive" style="width:100%;overflow:auto; max-height:500px;"> 
          <table class="table table-sm table-hover table-bordered table-striped">
            <thead>
              <tr>
                <th>Username</th>
                <th>Time</th>
              </tr>
            </thead>
            <tbody>
              <?php 
                for($j=1;$j<=$logged_in_users;$j++){ 
                  echo '<tr>
                        <td>'.$Name[$j].'</td>
                        <td>'.$time[$j].'</td>
                       </tr>';
                }
              ?>
            </tbody>
         </table>
        </div>
    </div>
  </div>
</div>

<?php
// _________________________________FOOTER_______________________________
	include(BASE_URL.'/src/header/footer.php'); // Includes Script
// _________________________________FOOTER_______________________________
?>
