
<?php
session_start();
//__________________________HEADER __________________________________________________________
define('BASE_URL', $_SERVER["DOCUMENT_ROOT"].'/BTP');
include(BASE_URL.'/src/header/header.php'); // INCLUDE HEADER FILE
//____________________________HEADER_________________________________________________________

	if(isset($_SESSION['login_user'])){
		;
	}
	else{
		header("location: /BTP/src/user/login_form.php");
	}

	if(isset($_GET['uid'])){
		$uid = $_GET['uid'];
	}else{
		header("Location: /BTP/pagenotfound.php");
	}

	$error_delete = NULL;


	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";


	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}

	$sql = "select * from user_login where id='".$uid."'";
	$result = mysqli_query($conn, $sql);

	if(mysqli_num_rows($result) == 1){

		$row = $result->fetch_assoc();

		$id= $row['id'];
		/// PROTECTION : SQL INJECTION !
		if($_SESSION['user_level']==5 ){  // only for admin
			;
		}
		else{
			header("Location: /BTP/pagenotfound.php");
		}

		$user_name = $row['user_name'];
		$level = $row['level'];
	}else{
		header("Location: /BTP/pagenotfound.php");
	}

	//////////////////////////////////////////////////   DELETE User /////////////////////////////
if (isset($_POST['submit_delete'])){

	$sql= "DELETE FROM user_login WHERE id='".$uid."'";
	$sql2= "DELETE FROM user_data WHERE id='".$uid."'";
	if (mysqli_query($conn, $sql) && mysqli_query($conn, $sql2)) {
		header("Location: /BTP/src/admin/manage_users.php", true, 301);
		exit();
		
	}else{
		$error_delete = "Unable to Delete Account, Please try again later!";
	}
}

	mysqli_close($conn); // Closing Connection

?>

<div class="container-fluid" style="margin-top:50px">
	<div class="row">
		<div class="col-md-2 sidenav ">
			<!-- Sidebar -->
			<h4>Happinezz</h4>
      <ul class="nav nav-pills nav-stacked">
        <li><a href="http://localhost/BTP/src/user/profile.php">Dashboard</a></li>
        <li><a href="http://localhost/BTP/src/user/update_profile.php">Update Profile</a></li>
        <li><a href="http://localhost/BTP/src/account_recovery/account_settings.php">Account Settings</a></li>
        <li><a href="http://localhost/BTP/src/blog/stories.php">Stories</a></li>
        <li><a href="http://localhost/BTP/src/comments/reviewcomments.php">Comments</a></li>
        <li><a href="http://localhost/BTP/src/form/loadforms.php">Psych-Tests</a></li>
        <li><a href="http://localhost/BTP/src/user/community.php">Community</a></li>
        <?php if($_SESSION['user_level']==5) { ?> 
        <li><a href="http://localhost/BTP/src/admin/view_logs.php">View Logs</a></li>
      	<li class="active"><a href="#">Manage Users</a></li>
        <li><a href="http://localhost/BTP/src/report/viewreports.php">Complaints</a></li>
        <li><a href="http://localhost/BTP/src/admin/view_form_response.php">User Reports</a></li>
        <?php } ?>
      </ul><br>
		</div>
		<div class="col-md-2">
		</div>
		<div class="col-md-10">	
			<h3>Delete User:</h3><br>
			<form class="form-horizontal" action="" method="post">
                
                <div class="form-group ">
                    <label class="col-sm-2 text-right" >User Name :</label>
                    <div class="col-sm-8">
                        <?php echo $user_name; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class=" col-sm-2 text-right" >User ID :</label>
                    <div class="col-sm-8">
                        <?php echo $uid; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class=" col-sm-2 text-right" >Level :</label>
                    <div class="col-sm-8">
                        <?php echo $level; ?>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-8">
                    	<!-- .......................................................... -->
                        <?php if($error_delete==NULL) {?>
                        <div> 
                            <?php } else {?>
                        <div style="margin-top: 5px;" class="alert alert-danger alert-dismissible in">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <?php } ?>
                        <?php echo $error_delete; ?>
                        </div>
                        <!-- .......................................................... -->
                        <input style="width=100%;" class="btn btn-danger" name="submit_delete" type="submit" value=" Confirm Deletion ">
                        &nbsp;
                        <a class="btn btn-primary" href="/BTP/src/admin/manage_users.php"> Back </a>
                    </div>
                </div> 
            </form>
		</div>
	</div>
</div>


<?php
// _________________________________FOOTER_______________________________
	include(BASE_URL.'/src/header/footer.php'); // Includes Script
// _________________________________FOOTER_______________________________
?>
