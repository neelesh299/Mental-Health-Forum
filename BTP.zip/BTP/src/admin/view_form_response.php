
<?php
session_start();
include('view_form_response_process.php'); // Includes Form Script
//__________________________HEADER __________________________________________________________
define('BASE_URL', $_SERVER["DOCUMENT_ROOT"].'/BTP');
include(BASE_URL.'/src/header/header.php'); // INCLUDE HEADER FILE
//____________________________HEADER_________________________________________________________

	if(isset($_SESSION['login_user'])){
		;
	}
	else{
		header("location: /BTP/src/user/login_form.php");
	}

?>

<div class="container-fluid" style="margin-top:50px">
	<div class="row">
		<div class="col-md-2 sidenav ">
			<!-- Sidebar -->
			<h4>Happinezz</h4>
      <ul class="nav nav-pills nav-stacked">
        <li><a href="http://localhost/BTP/src/user/profile.php">Dashboard</a></li>
        <li><a href="http://localhost/BTP/src/user/update_profile.php">Update Profile</a></li>
        <li><a href="http://localhost/BTP/src/account_recovery/account_settings.php">Account Settings</a></li>
        <li><a href="http://localhost/BTP/src/blog/stories.php">Stories</a></li>
        <li><a href="http://localhost/BTP/src/comments/reviewcomments.php">Comments</a></li>
        <li><a href="http://localhost/BTP/src/form/loadforms.php">Psych-Tests</a></li>
        <li><a href="http://localhost/BTP/src/user/community.php">Community</a></li>
        <?php if($_SESSION['user_level']==5) { ?> 
        <li><a href="http://localhost/BTP/src/admin/view_logs.php">View Logs</a></li>
      	<li><a href="http://localhost/BTP/src/admin/manage_users.php">Manage Users</a></li>
        <li><a href="http://localhost/BTP/src/report/viewreports.php">Complaints</a></li>
        <li class="active"><a href="http://localhost/BTP/src/admin/view_form_response.php">User Reports</a></li>
        <?php } ?>
      </ul><br>
		</div>
		<div class="col-md-2">
		</div>
		<div class="col-md-10">	
			<h1><a>User Reports</a></h1>
			<br>

			<div class="table-responsive" style="width:100%;overflow:auto; max-height:480px;"> 
        		<table class="table table-sm table-hover table-bordered table-striped">
            	<thead>
            		<tr>
                		<th>Sr. No.</th>
                		<th>Psych Test</th>
                		<th>Number of Users who tested</th>
                		<th>Average Score</th>
                    <th>Overall Health of users who tested</th>
            		</tr>
            	</thead>
            	<tbody>
            		<?php 
                		for($j=1;$j<=3;$j++){ 
                			echo '<tr>
                        		  <td>'.$j.'</td>';
                       		echo '<td>'.$test[$j].'</td>';
                       		echo '<td>'.$num[$j].'</td>';
                       		echo '<td>'.$score[$j].'</td>';
                       		echo '<td>'.$health[$j].'</td>';
                       		echo '</tr>';
                		}
              		?>
            	</tbody>
         		</table>
      </div>
      <div class="table-responsive" style="width:100%;overflow:auto; max-height:480px;"> 
        <h3>Depression Statistics :</h3>
            <table class="table table-sm table-hover table-bordered table-striped">
              <thead>
                <tr>
                    <th>Sr. No.</th>
                    <th>Category</th>
                    <th>Number of Users(who have tested)</th>
                </tr>
              </thead>
              <tbody>
                <?php 
                    for($j=1;$j<=6;$j++){ 
                      echo '<tr>
                              <td>'.$j.'</td>';
                          echo '<td>'.$depcat[$j].'</td>';
                          echo '<td>'.$depnum[$j].'</td>';
                          echo '</tr>';
                    }
                  ?>
              </tbody>
            </table>
      </div>
      <div class="table-responsive" style="width:100%;overflow:auto; max-height:480px;"> 
        <h3>Stress Statistics :</h3>
            <table class="table table-sm table-hover table-bordered table-striped">
              <thead>
                <tr>
                    <th>Sr. No.</th>
                    <th>Category</th>
                    <th>Number of Users(who have tested)</th>
                </tr>
              </thead>
              <tbody>
                <?php 
                    for($j=1;$j<=5;$j++){ 
                      echo '<tr>
                              <td>'.$j.'</td>';
                          echo '<td>'.$strcat[$j].'</td>';
                          echo '<td>'.$strnum[$j].'</td>';
                          echo '</tr>';
                    }
                  ?>
              </tbody>
            </table>
      </div>
      <div class="table-responsive" style="width:100%;overflow:auto; max-height:480px;"> 
        <h3>Anxiety Statistics :</h3>
            <table class="table table-sm table-hover table-bordered table-striped">
              <thead>
                <tr>
                    <th>Sr. No.</th>
                    <th>Category</th>
                    <th>Number of Users(who have tested)</th>
                </tr>
              </thead>
              <tbody>
                <?php 
                    for($j=1;$j<=3;$j++){ 
                      echo '<tr>
                              <td>'.$j.'</td>';
                          echo '<td>'.$anxcat[$j].'</td>';
                          echo '<td>'.$anxnum[$j].'</td>';
                          echo '</tr>';
                    }
                  ?>
              </tbody>
            </table>
      </div><br>
		</div><br>
	</div><br>
</div><br>


<?php
// _________________________________FOOTER_______________________________
	include(BASE_URL.'/src/header/footer.php'); // Includes Script
// _________________________________FOOTER_______________________________
?>
