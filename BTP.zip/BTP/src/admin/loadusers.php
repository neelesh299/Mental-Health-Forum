<?php

	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}

	$sql = "select * from user_login";
	$result = mysqli_query($conn, $sql);

	$no_of_users = $result->num_rows;

	for($i=1; $i<=$no_of_users; $i++){

		$row = $result->fetch_assoc();

		$user_id[$i]= $row['id'];
		$username[$i] = $row['user_name'];
		$level[$i] = $row['level'];

		if($level[$i]=='1'){
			$level[$i] = "User - Public";
		}else if($level[$i]=='2'){
			$level[$i] = "User - Private";
		}else if($level[$i]=='3'){
			$level[$i] = "Moderator";
		}else if($level[$i]=='4'){
			$level[$i] = "Manager";
		}else if($level[$i]=='5'){
			$level[$i] = "Admin";
		}

	}

?>