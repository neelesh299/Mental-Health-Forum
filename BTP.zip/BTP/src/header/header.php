<?php
	// Anything Important
	
?>
<!doctype HTML>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <!-- My Custom CSS-->
     <link rel="stylesheet" href="/BTP/styles.css">
    <title>Happinezz</title>
  </head>
  <body  >

    <nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container-fluid" >
      <div class="navbar-header">
         <a class="navbar-brand" href="http://localhost/BTP/index.php">Happinezz </a>
      </div>
      <ul class="nav navbar-nav">

          <?php if(basename($_SERVER['PHP_SELF'])=="index.php") {echo '<li class="active">';} else {echo '<li>';}?>
              <a href="http://localhost/BTP/index.php">Home</a>
          </li>
          <?php if(isset($_SESSION['login_user'])){ ?>
          <?php if(basename($_SERVER['PHP_SELF'])=="profile.php") {echo '<li class="active">';} else {echo '<li>';}?>
              <a href="http://localhost/BTP/src/user/profile.php">Dashboard</a>
          </li>
          <?php } ?>
          
         <?php if(isset($_SESSION['login_user'])){ ?>
          <?php if(basename($_SERVER['PHP_SELF'])=="blog.php") {echo '<li class="active">';} else {echo '<li>';}?>
              <a href="http://localhost/BTP/src/blog/blog.php">Blog</a>
          </li>
          <?php } ?>

          <?php if(basename($_SERVER['PHP_SELF'])=="moderation.php") {echo '<li class="active">';} else {echo '<li>';}?>
              <a href="http://localhost/BTP/moderation.php">Moderation Policy</a>
          </li>

          <?php if(basename($_SERVER['PHP_SELF'])=="privacy.php") {echo '<li class="active">';} else {echo '<li>';}?>
              <a href="http://localhost/BTP/privacy.php">Privacy Policy</a>
          </li>
      </ul>

      <ul class="nav navbar-nav navbar-right">
          <?php //session_start(); ?>
          <?php if(isset($_SESSION['login_user'])){ ?>
            <li>
              <a href="#">Hey <?php echo $_SESSION['login_user']; ?>!</a>
            </li>
            <li >
              <a href="http://localhost/BTP/src/user/logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a>
            </li>
          <?php } else { ?>
          <?php if(basename($_SERVER['PHP_SELF'])=="registration.php") {echo '<li class="active">';} else {echo '<li>';}?>
              <a href="http://localhost/BTP/src/user/registration.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a>
          </li>
          <?php if(basename($_SERVER['PHP_SELF'])=="login_form.php") {echo '<li class="active">';} else {echo '<li>';}?>
              <a href="http://localhost/BTP/src/user/login_form.php"><span class="glyphicon glyphicon-log-in"></span> Login</a>
          </li>
          <?php } // end of else?>
      </ul>
    </div>
</nav> 

