<?php
include('recover_pass_process.php'); // Includes Script

if(isset($_SESSION['login_user'])){
	header("location: /BTP/src/user/profile.php");
}
//__________________________HEADER __________________________________________________________
define('BASE_URL', $_SERVER["DOCUMENT_ROOT"].'/BTP');
include(BASE_URL.'/src/header/header.php'); // INCLUDE HEADER FILE
//____________________________HEADER_________________________________________________________
?>



<div class="container-fluid" style="margin-top:50px">
	
	<div class="row">
		<div class="col-md-3">
			<!-- Sidebar -->
		</div>
		<div class="col-md-9">
			<br>
			<h3>Change Your Password: </h3>
			<form class="form-horizontal" action="" method="post">
				<div class="form-group">
					<label  class="control-label col-sm-2" >Input Username :</label>
					<div class="col-sm-4">
						<input class="form-control" id="name" name="username" placeholder="username" type="text">
					</div>
				</div>
				<div class="form-group">
    				<div class="col-sm-offset-2 col-sm-4">
						
						<?php if($error_username==NULL) {?>
							<div> 
						<?php } else {?>
							<div style="margin-top: 5px;" class="alert alert-danger alert-dismissible in">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						<?php } ?>
								<?php echo $error_username; ?>
							</div>
						<input style="width=100%;" class="btn btn-primary" name="submit_username" type="submit" value=" Proceed ">
					</div>
				</div>
			</form>
		</div>
	</div>
</div>

<?php
// _________________________________FOOTER_______________________________
	include(BASE_URL.'/src/header/footer.php'); // Includes Script
// _________________________________FOOTER_______________________________
?>
