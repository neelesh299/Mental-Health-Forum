<?php
session_start(); 
$error_username='';

	// DATABASE  SE KARO CONNECT BHAIYAJI...
	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}

	if (isset($_POST['submit_username'])) { 
	if (empty($_POST['username'])) {
		$error_username = "Username is invalid!";
	}
	else{
		// Ask for security question and answer !

		$username=$_POST['username'];
	
		$username = stripslashes($username);
		$username = mysqli_real_escape_string($conn, $username);

		$sql = "select * from user_login where user_name = '$username'";
		$result = mysqli_query($conn, $sql);

		if ($result->num_rows == 0) {
			$error_username = "Username not Found!";
		}else{
			$_SESSION['recover']=$username;
			header("location: /BTP/src/account_recovery/security_ques.php");
		}
	}// close else of - username is valid
}//  Submit username if(close)

mysqli_close($conn); // Closing Connection

?>
