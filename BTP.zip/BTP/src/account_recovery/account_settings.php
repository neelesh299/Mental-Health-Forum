<?php
session_start(); 
include('account_settings_process.php'); // Includes Script

if(isset($_SESSION['login_user'])){
	;
}else{
	header("location: /BTP/src/user/login_form.php");
}
	define('BASE_URL', $_SERVER["DOCUMENT_ROOT"].'/BTP');
	include(BASE_URL.'/src/header/header.php'); // INCLUDE HEADER FILE
?>


<div class="container-fluid" style="margin-top:50px">
	<div class="row">
		<div class="col-md-2 sidenav ">
			<!-- Sidebar -->
			<h4>Happinezz</h4>
      <ul class="nav nav-pills nav-stacked">
        <li><a href="http://localhost/BTP/src/user/profile.php">Dashboard</a></li>
        <li><a href="http://localhost/BTP/src/user/update_profile.php">Update Profile</a></li>
        <li class="active"><a href="http://localhost/BTP/src/account_recovery/account_settings.php">Account Settings</a></li>
        <li><a href="http://localhost/BTP/src/blog/stories.php">Stories</a></li>
        <li><a href="http://localhost/BTP/src/comments/reviewcomments.php">Comments</a></li>
        <li><a href="http://localhost/BTP/src/form/loadforms.php">Psych-Tests</a></li>
        <li><a href="http://localhost/BTP/src/user/community.php">Community</a></li>
        <?php if($_SESSION['user_level']==5) { ?> 
        <li><a href="http://localhost/BTP/src/admin/view_logs.php">View Logs</a></li>
		<li><a href="http://localhost/BTP/src/admin/manage_users.php">Manage Users</a></li>
        <li><a href="http://localhost/BTP/src/report/viewreports.php">Complaints</a></li>
        <li><a href="http://localhost/BTP/src/admin/view_form_response.php">User Reports</a></li>
        <?php } ?>
      </ul><br>
		</div>
		<div class="col-md-2">
		</div>
		<div class="col-md-5">	
			<br>
			<!-- //////////////////////////////////////////////////////////////////////////////////-->
			<h4>Change Account Username/Password: </h4>
			<form action="" class="form-horizontal" method="post">
				<div class="form-group">
					<label class="control-label col-sm-4">Username :</label>
					<div class="col-sm-8">
						<?php echo '<input id="name" class="form-control" name="username" value="'.$username.'" type="text">'; ?>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-4">Password :</label>
					<div class="col-sm-8">
						<?php echo '<input id="password" class="form-control" name="password" value="'.$password.'" type="password">';?>
					</div>
				</div>
				<div class="form-group">
    				<div class="col-sm-offset-4 col-sm-8">
    					<?php if($error_username==NULL) {?>
							<div> 
						<?php } else {?>
							<div style="margin-top: 5px;" class="alert alert-danger alert-dismissible in">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						<?php } ?>
								<?php echo $error_username; ?>
							</div>
						<?php if($message_username==NULL) {?>
							<div> 
						<?php } else {?>
							<div style="margin-top: 5px;" class="alert alert-success alert-dismissible in">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						<?php } ?>
								<?php echo $message_username; ?>
							</div>
    					<input name="submit_username" class="btn btn-success" type="submit" value=" Save Changes ">
    				</div>
    			</div>
			</form>
			<!-- ###################################################################################  -->
			<hr>
			<h4>Change Account Privacy: </h4>
			<form action="" class="form-horizontal" method="post">
				<div class="form-group">
					<label class="control-label col-sm-4">Account Type :</label>
					<div class="col-sm-8">
						<select class="form-control" name="level">
						<?php
							if($level==1){
								echo '<option value="1" selected >Public Account</option>
								<option value="2">Private Account</option>';
							}else if($level==2){
								echo '<option value="1">Public Account</option>
								<option value="2" selected>Private Account</option>';
							}else {
								echo '<option selected disabled>Not Applicable</option>';
							}  ?>
						</select>
					</div>
				</div>
				<div class="form-group">
    				<div class="col-sm-offset-4 col-sm-8">
    					<?php if($error_privacy==NULL) {?>
							<div> 
						<?php } else {?>
							<div style="margin-top: 5px;" class="alert alert-danger alert-dismissible in">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						<?php } ?>
								<?php echo $error_privacy; ?>
							</div>
						<?php if($message_privacy==NULL) {?>
							<div> 
						<?php } else {?>
							<div style="margin-top: 5px;" class="alert alert-success alert-dismissible in">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						<?php } ?>
								<?php echo $message_privacy; ?>
							</div>
    					<input name="submit_privacy" class="btn btn-success" type="submit" value=" Save Changes ">
    				</div>
    			</div>
			</form>
			<!-- ###################################################################################  -->
		</div>
		<div class="col-md-5">	
			<br>
			<!-- //////////////////////////////////////////////////////////////////////////////////-->
			<h4>Change Account Security Question/Answer: </h4>
			<form action="" class="form-horizontal" method="post">
				<div class="form-group">
					<label class="control-label col-sm-4">Security question :</label>
					<div class="col-sm-8">
						<?php echo '<select class="form-control" name="question">
							<option disabled selected value="'.$question.'">'.$question.'</option>
							<option value="What Is your favorite book?">What Is your favorite book?</option>
							<option value="What was the name of your first/current/favorite pet?">What was the name of your first/current/favorite pet?</option>
							<option value="What was the first company that you worked for?">What was the first company that you worked for?</option>
							<option value="What is your favorite food?">What is your favorite food?</option>
							<option value="Where is your favorite place to vacation?">Where is your favorite place to vacation?</option>
							<option value="What city were you born in?">What city were you born in?</option>
						</select>'; ?>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-4">Answer :</label>
					<div class="col-sm-8">
						<?php echo '<input class="form-control" id="name" name="answer" value="'.$answer.'" type="text">';?>
					</div>
				</div>
				<div class="form-group">
    				<div class="col-sm-offset-4 col-sm-8">
    					<?php if($error_ques==NULL) {?>
							<div> 
						<?php } else {?>
							<div style="margin-top: 5px;" class="alert alert-danger alert-dismissible in">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						<?php } ?>
								<?php echo $error_ques; ?>
							</div>
						<?php if($message_ques==NULL) {?>
							<div> 
						<?php } else {?>
							<div style="margin-top: 5px;" class="alert alert-success alert-dismissible in">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						<?php } ?>
								<?php echo $message_ques; ?>
							</div>
    					<input name="submit_question" class="btn btn-success" type="submit" value=" Save Changes ">
    				</div>
    			</div>
			</form>
			<!-- ###################################################################################  -->
			<hr>
			<h4>Delete Your Account:: </h4>
			<form class="form-horizontal" action="" method="post">
				<div class="form-group">
				<?php
					if($delete_confirm==1){
						echo '<div style="margin-top: 5px;" class="alert alert-danger alert-dismissible in">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						Your Current session will be logged out automatically after you proceed deleting your account!
						</div>
						<label class="control-label col-sm-4">Click Here to Confirm Account Deletion - </label>
						<div class="col-sm-8">
						<input class="btn btn-danger" name="submit_confirm" type="submit" value="Confirm Account Deletion!">
						</div>';
					}else{
							if($error_delete==NULL) {
								;
							}else{
								echo '<div style="margin-top: 5px;" class="alert alert-success alert-dismissible in">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>';
								echo $error_delete;
								echo '</div>';
								}
						echo '
						<label class="control-label col-sm-4"> Click here to delete your account - </label> 
						<div class="col-sm-8">
						<input class="btn btn-danger" name="submit_delete" type="submit" value=" Delete Account ">
						</div>';
					}
				?>
				</div>
			</form>
			<!-- ###################################################################################  -->

		</div>
	</div>
</div>

<?php
// _________________________________FOOTER_______________________________
	include(BASE_URL.'/src/header/footer.php'); // Includes Script
// _________________________________FOOTER_______________________________
?>
