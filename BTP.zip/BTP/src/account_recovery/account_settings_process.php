<?php
//session_start(); 
$error=''; 
$message='';
$error_username=''; 
$message_username='';
$error_ques=''; 
$message_ques='';
$error_privacy=''; 
$message_privacy='';
$delete_confirm=0;
$error_delete='';


$id = $_SESSION['user_id'];

	// DATABASE  SE KARO CONNECT BHAIYAJI...
	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}

	$sql = "select * from user_login where id='$id'";
	$result = mysqli_query($conn, $sql);
	$row = $result->fetch_assoc();

	$username 	=$row['user_name'];
	$username2 	=$row['user_name'];
	$password 	=$row['user_password'];
	$password2 	=$row['user_password'];

	$level 		=$row['level'];
	$level2		=$row['level'];

	$question	=$row['security_ques'];
	$answer 	=$row['ans'];
	$question2	=$row['security_ques'];
	$answer2 	=$row['ans'];

// ####################################################################################################\
if (isset($_POST['submit_username'])) {
	if (empty($_POST['username']) || empty($_POST['password'])) {
		$error_username = "Username or Password is invalid!";
	}
	else{
	
		$username=$_POST['username'];
		$password=$_POST['password'];
	
		$username = stripslashes($username);
		$password = stripslashes($password);
		$username = mysqli_real_escape_string($conn, $username);
		$password = mysqli_real_escape_string($conn, $password);
	
		$sql = "select * from user_login where user_name = '$username' AND id <>'$id'";
		$result = mysqli_query($conn, $sql);
	
		if ($result->num_rows > 0) {
			$error_username = "Username already exists! Please choose a different username!";
			$username=$username2;
			$password=$password2;
		}else{
			$sql2= "UPDATE user_login SET user_name='".$username."', user_password='".$password."' where id='".$id."'";

			if (mysqli_query($conn, $sql2)) {
    			$message_username = "credentials saved successfully! ";
			} else {
    			$error_username = "Unable to save changes, Please try again later!";
			}
		}
	
	}
}


// ####################################################################################################\
if (isset($_POST['submit_question'])) {
	if (empty($_POST['question']) || empty($_POST['answer'])) {
		$error_ques = "Question or Answer is invalid!";
	}
	else{
	
		$question=$_POST['question'];
		$answer=$_POST['answer'];
	
		$question = mysqli_real_escape_string($conn, $question);
		$answer = mysqli_real_escape_string($conn, $answer);
	
		$sql= "UPDATE user_login SET security_ques='".$question."',ans='".$answer."' where id='".$id."'";

		if (mysqli_query($conn, $sql)) {
    		$message_ques = "Changes saved successfully! ";
		} else {
    		$error_ques = "Unable to save changes, Please try again later!";
    		$question=$question2;
    		$answer=$answer2;
		}
	
	}
}


// ####################################################################################################\
if (isset($_POST['submit_privacy'])) {
	if (empty($_POST['level'])) {
		$error_privacy = "Selceted privacy option is invalid!";
	}
	else{
	
		$level=$_POST['level'];
	
		$sql= "UPDATE user_login SET level='".$level."' where id='".$id."'";

		if (mysqli_query($conn, $sql)) {
    		$message_privacy = "Changes saved successfully! ";
		} else {
    		$error_privacy = "Unable to save changes, Please try again later!";
    		$level=$level2;
		}
	
	}
}



// ####################################################################################################\
if (isset($_POST['submit_delete'])) {
	$delete_confirm=1;
}
if (isset($_POST['submit_confirm'])) {
	$sql= "DELETE FROM user_login WHERE id='".$id."'";
	$sql2= "DELETE FROM user_data WHERE id='".$id."'";
	if (mysqli_query($conn, $sql) && mysqli_query($conn, $sql2)) {
		header("Location: /BTP/src/user/logout.php", true, 301);
		exit();
	}else{
		$delete_confirm=0;
		$error_delete = "Unable to Delete Account, Please try again later!";
	}
}


mysqli_close($conn); // Closing Connection


?>