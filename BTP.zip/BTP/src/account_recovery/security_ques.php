<?php
session_start(); 

if(isset($_SESSION['login_user'])) {
	header("location: /BTP/src/user/profile.php");
} else if(!isset($_SESSION['recover'])) {
	header("location: /BTP/src/account_recovery/recover_pass.php");
}

$error_ans=''; 

	// DATABASE  SE KARO CONNECT BHAIYAJI...
	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}
	$username= $_SESSION['recover'];
	$sql = "select * from user_login where user_name = '$username'";
	$result = mysqli_query($conn, $sql);
	$row = $result->fetch_assoc();

	$question = $row['security_ques'];
	$ans = $row['ans'];
	// After submitting form..............

	if (isset($_POST['submit_ans'])){
		if (empty($_POST['answer'])) {
			$error_ans = "Answer to the Security Question is invalid!";
		}
		else{
			if($_POST['answer']==$ans){
				$_SESSION['recover']=$username;
				$_SESSION['ans']=TRUE;
				header("location: /BTP/src/account_recovery/pass_reset.php");
			}// end of answer matched !
			else{
				// wrong ans
				$error_ans = "Answer to the Security Question is Wrong!";
			}
		}// end of else answer not empty!
	}// end of if(submit_ans)!

	
//__________________________HEADER __________________________________________________________
define('BASE_URL', $_SERVER["DOCUMENT_ROOT"].'/BTP');
include(BASE_URL.'/src/header/header.php'); // INCLUDE HEADER FILE
//____________________________HEADER_________________________________________________________
?>


<div class="container-fluid" style="margin-top:50px">
	<br>
	<div class="row">
		<div class="col-md-3">
			<!-- Sidebar -->
		</div>
		<div class="col-md-9">
			<h3>Change Your Password: </h3>
			<form class="form-horizontal" action="" method="post"><br>
				<div class="form-group">
					<label  class="control-label col-sm-2" >Security Question:</label>
					<div class="col-sm-4">
						 <h4><?php echo $question; ?></h4>
					</div>
				</div>
				
				<div class="form-group">
					<label  class="control-label col-sm-2" >Answer :</label>
					<div class="col-sm-4">
						<input class="form-control" id="name" name="answer" placeholder="answer" type="text">
					</div>
				</div>
				<div class="form-group">
    				<div class="col-sm-offset-2 col-sm-4">
						
						<?php if($error_ans==NULL) {?>
							<div> 
						<?php } else {?>
							<div style="margin-top: 5px;" class="alert alert-danger alert-dismissible in">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						<?php } ?>
								<?php echo $error_ans; ?>
							</div>
						<input style="width=100%;" class="btn btn-primary" name="submit_ans" type="submit" value=" Verify ">
					</div>
				</div>
			</form>
		</div>
	</div>
</div>


<?php
// _________________________________FOOTER_______________________________
	include(BASE_URL.'/src/header/footer.php'); // Includes Script
// _________________________________FOOTER_______________________________
?>
