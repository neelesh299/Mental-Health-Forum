<?php
session_start(); 


if(isset($_SESSION['login_user'])){
	header("location: /BTP/src/user/profile.php");
}else if(!isset($_SESSION['recover'])){
	header("location: /BTP/src/account_recovery/recover_pass.php");
}else if(!isset($_SESSION['ans'])){
	header("location: /BTP/src/account_recovery/security_ques.php");
}

$error_pass='';
$message_pass='';

$username=$_SESSION['recover'];

	// DATABASE  SE KARO CONNECT BHAIYAJI...
	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}

	if (isset($_POST['submit_pass'])) {
		if (empty($_POST['pass']) || empty($_POST['repeat'])) {
			$error_pass = "Please input a valid password!";
		}
		else if($_POST['pass']==$_POST['repeat']){
			// save new credentials
			$newpass = stripslashes($_POST['pass']);
			$newpass = mysqli_real_escape_string($conn, $newpass);
			$sql2= "UPDATE user_login SET user_password='".$newpass."' where user_name='".$username."'";
			if (mysqli_query($conn, $sql2)) {
				
				if(session_destroy()) // Destroying All Sessions
				{
					echo '<script language="javascript">';
					echo 'alert("Credentials were saved !\n Redirecting to Login page...");' ;
					echo 'window.location = "/BTP/src/user/login_form.php";' ;
					echo '</script>';
				}
			}
			else{
				$error_pass = "Unable to save changes, Please try again later!";
			}
		}
		else{
			$error_pass = "Passwords didn't match! Please input again!";
		}
	}
//__________________________HEADER __________________________________________________________
define('BASE_URL', $_SERVER["DOCUMENT_ROOT"].'/BTP');
include(BASE_URL.'/src/header/header.php'); // INCLUDE HEADER FILE
//____________________________HEADER_________________________________________________________
?>


<div class="container-fluid" style="margin-top:50px">
	
	<div class="row">
		<div class="col-md-3">
			<!-- Sidebar -->
		</div>
		<div class="col-md-9">
			<h3>Change Your Password: </h3>
			<form action="" class="form-horizontal" method="post">
				<div class="form-group">
					<label  class="control-label col-sm-2" >New Password:</label>
					<div class="col-sm-4">
						<input class="form-control"  id="name" name="pass" placeholder="********" type="password"><br>
					</div>
				</div>
				<div class="form-group">
					<label  class="control-label col-sm-2">Repeat New Password :</label>
					<div class="col-sm-4">
						<input class="form-control" id="password" name="repeat" placeholder="********" type="password"><br>
					</div>
				</div>
				<div class="form-group">
    				<div class="col-sm-offset-2 col-sm-4">
						
						<?php if($error_pass==NULL) {?>
							<div> 
						<?php } else {?>
							<div style="margin-top: 5px;" class="alert alert-danger alert-dismissible in">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						<?php } ?>
								<?php echo $error_pass; ?>
							</div>
						<?php if($message_pass==NULL) {?>
							<div> 
						<?php } else {?>
							<div style="margin-top: 5px;" class="alert alert-success alert-dismissible in">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						<?php } ?>
								<?php echo $message_pass; ?>
							</div>
						<input style="width=100%;" class="btn btn-success" name="submit_pass" type="submit" value=" Save Credentials "><br>
					</div>
				</div>

				
			</form>
		</div>
	</div>
</div>

<?php
// _________________________________FOOTER_______________________________
	include(BASE_URL.'/src/header/footer.php'); // Includes Script
// _________________________________FOOTER_______________________________
?>
