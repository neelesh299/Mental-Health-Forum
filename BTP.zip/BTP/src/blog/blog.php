<?php
session_start();
//__________________________HEADER __________________________________________________________
define('BASE_URL', $_SERVER["DOCUMENT_ROOT"].'/BTP');
include(BASE_URL.'/src/header/header.php'); // INCLUDE HEADER FILE
//____________________________HEADER_________________________________________________________


	if(isset($_SESSION['login_user'])){
		;
	}
	else{
		header("location: /BTP/src/user/login_form.php");
	}
?>

<?php
	$level = $_SESSION['user_level'];
	$message="";

	// ...............................LOADING THE BLOG POSTS FROM THE DATABASE........................................
	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}

	if($level==1||$level==2){
		$sql = "SELECT * FROM blog WHERE status=2 and privacy=0 order by pid desc"; // Showing only Public Posts !
	}
	else{
		$sql = "SELECT * FROM blog WHERE status=2 order by pid desc"; // Showing Public and Private Posts !
	}

	$result = mysqli_query($conn, $sql);

	$no_of_stories = $result->num_rows;

	for($j=1;$j<=$no_of_stories;$j++){

		$row = $result->fetch_assoc();

		$userid[$j] = $row['id']; // For Displaying the User's Name
		$title[$j] = $row['title'];
		$date[$j] = $row['dateofpublish'];
		$post[$j] = $row['post'];
		$privacy[$j] = $row['privacy'];
		$pid[$j] = $row['pid'];

		$sql2 = "SELECT * FROM user_data where id=".$userid[$j].""; // FOR USER'S NAME
		$result2 = mysqli_query($conn, $sql2);
		$row2 = $result2->fetch_assoc();
		$fname[$j] = $row2['firstname']; 
		$lname[$j] = $row2['lastname']; 

		// retrieve Comments ..
		$sql3 = "SELECT * FROM comments where pid=".$pid[$j]." and stat=1";
		$rescom = mysqli_query($conn, $sql3);

		$no_of_comments[$j] = $rescom->num_rows;
		for($k=1;$k<=$no_of_comments[$j];$k++){
			$rowc = $rescom->fetch_assoc();
			$ccid[$j][$k]= $rowc['cid'];
			$cuid[$j][$k]= $rowc['uid'];
			$cpid[$j][$k]= $rowc['pid'];
			$cstat[$j][$k]= $rowc['stat'];
			$cdata[$j][$k]= $rowc['comments'];
			$cname[$j][$k]= $rowc['username'];
		}



	}// end of FOR LOOP


if (isset($_POST['comment'])) {
	$comment_uid  = $_SESSION['user_id'];
	$comment_pid = $_POST['pid'];
	$comment_data = $_POST['comment_data'];
	$username = $_SESSION['login_user'];
	$stat = 0; // 0 for under review !

	$sql_c = "INSERT INTO comments (pid,uid,stat,comments,username)
	VALUES (".$comment_pid.",".$comment_uid.",0,'".$comment_data."','".$username."')";

	if (mysqli_query($conn, $sql_c)) {
    			$message = "Comment posted. It will be published after review by moderators! ";
			}else{
				$message = mysql_error();
			}
}


?>

<!-- ...............................................DISPLAY PART........................... -->
<div class="container-fluid" style="margin-top:50px">
	<h1>Stories by Community Members:</h1><br>
	<div class="row">
		<div class="col-md-1">
			<!-- Sidebar -->
		</div>
					
    								
		<div class="col-md-10">
    								<?php if($message==NULL) {?>
										<div> 
											<?php } else {?>
										<div style="margin-top: 5px;" class="alert alert-success alert-dismissible in">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
											<?php } ?>
											<?php echo $message; ?>
										</div>
			<p class="text-default text-center"><small>Click on the Title to Read the Stories</small></p>
			<div class="panel-group" id="accordion">
  				<?php
  				for($j=1;$j<=$no_of_stories;$j++){
  				?>
  				<div class="panel panel-default">
    				<div class="panel-heading">
      					<h4 class="panel-title">
        				<a class="accordion-toggle" data-toggle="collapse" href="#collap<?php echo $pid[$j]; ?>">
        					<?php echo $title[$j]; ?> 
        				</a>
        				<small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Published on <?php echo $date[$j]; ?> </small>
      					</h4>
    				</div>

    				<div id="collap<?php echo $pid[$j]; ?>" class="panel-collapse collapse ">
      					<div class="panel-body">
      						
      						<?php echo nl2br($post[$j]).'<br><br>'; 

      						if($level==3||$level==4||$level==5){
      							if($privacy[$j]==0){
      								echo '<span class="text-success text-left">Privacy - Public</span>';
      							}else{
      								echo '<span class="text-danger text-left">Privacy - Private</span>';
      							}
      						}							
      						?>
      						&nbsp;<span class="text-info text-right">Author - <?php echo $fname[$j]." ".$lname[$j]; ?></span>
      						<?php
      						echo '<a class="text-danger" href="/BTP/src/report/reportcontent.php?cid='.$pid[$j].'&type=1">&nbsp;&nbsp;&nbsp;--Report Post--</a>';
      						?>
      						<br>
      						<!-- Display Comments-->
      						<div class="col-sm-2">
								<br><b>Comments:</b><br>
							</div>
      						<div class="col-sm-10">
      							<br>
      						<?php 
								for($k=1;$k<=$no_of_comments[$j];$k++){?>
      								<p> <?php echo $cdata[$j][$k]; ?> <br>
      								<small> - <?php echo $cname[$j][$k]; ?>
      									<?php
      										echo '<a class="text-danger" href="/BTP/src/report/reportcontent.php?cid='.$ccid[$j][$k].'	&type=0">&nbsp;&nbsp;&nbsp;--Report Comment--</a>';
      									?>
      								</small> </p>
								<?php }
								if($no_of_comments[$j]==0){
									echo "<p><small> - - - Be the first one to comment! - - - </small> </p>";
								}
      						?>
      						</div>
      						
      						<!-- Write Comments-->
      						<br>
      						<form name="form" class="form-horizontal" action="" method="POST">
				
								<div class="form-group">
									<div class="col-sm-2">
										
									</div>
									<div class="col-sm-6">
										<input class="form-control"  id="comment_data" name="comment_data" placeholder="Type your comment here" type="text">
										<input type="hidden" name="pid" value="<?php echo $pid[$j]; ?>">
									</div>
									<div class="col-sm-2">
										<input class="btn btn-primary" name="comment" type="submit" value="Comment">
									</div>

								</div>

								
							</form>

      					</div>
    				</div>
  				</div>
  				<?php
  				}// End of for loop
  				?>
  			</div> <!-- End of Accordation (Blog Posts) -->
  			<p class="text-default text-center"><small>No More Stories</small></p>
  		</div>

		<div class="col-md-1">
			<!-- Sidebar -->
		</div>
	</div>
</div>

<?php
// _________________________________FOOTER_______________________________
	include(BASE_URL.'/src/header/footer.php'); // Includes Script
// _________________________________FOOTER_______________________________
?>
