
<?php
session_start();
//__________________________HEADER __________________________________________________________
define('BASE_URL', $_SERVER["DOCUMENT_ROOT"].'/BTP');
include(BASE_URL.'/src/header/header.php'); // INCLUDE HEADER FILE
//____________________________HEADER_________________________________________________________
include('loadstories.php');

	if(isset($_SESSION['login_user'])){
		;
	}
	else{
		header("location: /BTP/src/user/login_form.php");
	}

?>

<div class="container-fluid" style="margin-top:50px">
	<div class="row">
		<div class="col-md-2 sidenav ">
			<!-- Sidebar -->
			<h4>Happinezz</h4>
      <ul class="nav nav-pills nav-stacked">
        <li><a href="http://localhost/BTP/src/user/profile.php">Dashboard</a></li>
        <li><a href="http://localhost/BTP/src/user/update_profile.php">Update Profile</a></li>
        <li><a href="http://localhost/BTP/src/account_recovery/account_settings.php">Account Settings</a></li>
        <li class="active"><a href="http://localhost/BTP/src/blog/stories.php">Stories</a></li>
        <li><a href="http://localhost/BTP/src/comments/reviewcomments.php">Comments</a></li>
        <li><a href="http://localhost/BTP/src/form/loadforms.php">Psych-Tests</a></li>
        <li><a href="http://localhost/BTP/src/user/community.php">Community</a></li>
        <?php if($_SESSION['user_level']==5) { ?> 
        <li><a href="http://localhost/BTP/src/admin/view_logs.php">View Logs</a></li>
      	<li><a href="http://localhost/BTP/src/admin/manage_users.php">Manage Users</a></li>
        <li><a href="http://localhost/BTP/src/report/viewreports.php">Complaints</a></li>
        <li><a href="http://localhost/BTP/src/admin/view_form_response.php">User Reports</a></li>
        <?php } ?>
      </ul><br>
		</div>
		<div class="col-md-2">
		</div>
		<div class="col-md-10">	
			<h2>Stories: &nbsp;&nbsp;<a class="btn btn-success" href="/BTP/src/blog/newstory.php">Write a Story</a></h2>
			
			<div class="table-responsive" style="width:100%;overflow:auto; max-height:480px;"> 
        		<table class="table table-sm table-hover table-bordered table-striped">
            	<thead>
            		<tr>
                		<th>Sr. No.</th>
                		<?php if($level==3||$level==4||$level==5){
                			echo '<th>User ID</th>';
                		}?>
                		<th>Title</th>
                		<th>Status</th>
                		<th>Privacy</th>
                		<th>Date</th>
                		<th>Edit</th>
                		<?php if($level==3||$level==4||$level==5){
                			echo '<th>Change Status</th>';
                		}?>
                		<th>Delete</th>
            		</tr>
            	</thead>
            	<tbody>
            		<?php 
                		for($j=1;$j<=$no_of_stories;$j++){ 
                			echo '<tr>
                        		<td>'.$j.'</td>';
                        		if($level==3||$level==4||$level==5){
                        			echo '<td>'.$userid[$j].'</td>';
                        		}
                       		echo '
                        		<td>'.$title[$j].'</td>
                        		<td>'.$status[$j].'</td>';
                            if($privacy[$j]==0){
                                echo '<td><p class="text-default">Public</p></td>';
                            }else if($privacy[$j]==1){
                                echo '<td><p class="text-danger"><b>Private</b></p></td>';
                            }
                            echo '
                                <td>'.$date[$j].'</td>
                        		<td> <a class="btn btn-success center-block" href="/BTP/src/blog/editstory.php?pid='.$pid[$j].'">Edit</a> </td>';
                        		if($level==3||$level==4||$level==5){
                                    if($statno[$j] != 0){  // checking for drafts
                        			    echo '<td> <a class="btn btn-primary center-block" href="/BTP/src/blog/editstatus.php?pid='.$pid[$j].'">Change Status</a> </td>';
                                    }else{
                                       echo '<td> <center> <h5>-</h5> </center> </td>';
                                    }
                        		}
                       		echo '<td> <a class="btn btn-danger center-block" href="/BTP/src/blog/deletestory.php?pid='.$pid[$j].'">Delete</a> </td>
                       			</tr>';
                		}
              		?>
            	</tbody>
         		</table>
        	</div>
		</div>
	</div>
</div>


<?php
// _________________________________FOOTER_______________________________
	include(BASE_URL.'/src/header/footer.php'); // Includes Script
// _________________________________FOOTER_______________________________
?>
