
<?php
session_start();
//__________________________HEADER __________________________________________________________
define('BASE_URL', $_SERVER["DOCUMENT_ROOT"].'/BTP');
include(BASE_URL.'/src/header/header.php'); // INCLUDE HEADER FILE
//____________________________HEADER_________________________________________________________

	if(isset($_SESSION['login_user'])){
		;
	}
	else{
		header("location: /BTP/src/user/login_form.php");
	}

	if(isset($_GET['pid'])){
		$pid = $_GET['pid'];
	}else{
		header("Location: /BTP/pagenotfound.php");
	}
	$error_delete = NULL;


	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	$id = $_SESSION['user_id'];
	$level = $_SESSION['user_level'];

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}

	$sql = "select * from blog where pid='".$pid."'";
	$result = mysqli_query($conn, $sql);

	if(mysqli_num_rows($result) == 1){

		$row = $result->fetch_assoc();

		$id= $row['id'];
		/// PROTECTION : SQL INJECTION !
		if($_SESSION['user_id']==$id || $_SESSION['user_level']==3 || $_SESSION['user_level']==2 || $_SESSION['user_level']==5 ){
			;
		}
		else{
			header("Location: /BTP/pagenotfound.php");
		}

		$title = $row['title'];
		$userid = $row['id'];
		$date = $row['dateofpublish'];
	}else{
		header("Location: /BTP/pagenotfound.php");
	}

	//////////////////////////////////////////////////   DELETE POST /////////////////////////////
	if (isset($_POST['submit_delete'])) {
		$sql = "Delete from blog where pid='".$pid."'";
		
		if (mysqli_query($conn, $sql)) {
			header("Location: /BTP/src/blog/stories.php");
		}else{
			$error_delete = "Unable to Delete Account, Please try again later!";
		}
	}

	mysqli_close($conn); // Closing Connection

?>

<div class="container-fluid" style="margin-top:50px">
	<div class="row">
		<div class="col-md-2 sidenav ">
			<!-- Sidebar -->
			<h4>Happinezz</h4>
      <ul class="nav nav-pills nav-stacked">
        <li><a href="http://localhost/BTP/src/user/profile.php">Dashboard</a></li>
        <li><a href="http://localhost/BTP/src/user/update_profile.php">Update Profile</a></li>
        <li><a href="http://localhost/BTP/src/account_recovery/account_settings.php">Account Settings</a></li>
        <li class="active"><a href="http://localhost/BTP/src/blog/stories.php">Stories</a></li>
        <li><a href="http://localhost/BTP/src/comments/reviewcomments.php">Comments</a></li>
        <li><a href="http://localhost/BTP/src/form/loadforms.php">Psych-Tests</a></li>
        <li><a href="http://localhost/BTP/src/user/community.php">Community</a></li>
        <?php if($_SESSION['user_level']==5) { ?> 
        <li><a href="http://localhost/BTP/src/admin/view_logs.php">View Logs</a></li>
      	<li><a href="http://localhost/BTP/src/admin/manage_users.php">Manage Users</a></li>
        <li><a href="http://localhost/BTP/src/report/viewreports.php">Complaints</a></li>
        <li><a href="http://localhost/BTP/src/admin/view_form_response.php">User Reports</a></li>
        <?php } ?>
      </ul><br>
		</div>
		<div class="col-md-2">
		</div>
		<div class="col-md-10">	
			<h3>Delete Story:</h3><br>
			<form class="form-horizontal" action="" method="post">
                
                <div class="form-group ">
                    <label class="col-sm-2 text-right" >Story Title :</label>
                    <div class="col-sm-8">
                        <?php echo $title; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class=" col-sm-2 text-right" >User ID :</label>
                    <div class="col-sm-8">
                        <?php echo $userid; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label class=" col-sm-2 text-right" >Date :</label>
                    <div class="col-sm-8">
                        <?php echo $date; ?>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-8">
                    	<!-- .......................................................... -->
                        <?php if($error_delete==NULL) {?>
                        <div> 
                            <?php } else {?>
                        <div style="margin-top: 5px;" class="alert alert-danger alert-dismissible in">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <?php } ?>
                        <?php echo $error_delete; ?>
                        </div>
                        <!-- .......................................................... -->
                        <input style="width=100%;" class="btn btn-danger" name="submit_delete" type="submit" value=" Confirm Deletion ">
                        &nbsp;
                        <a class="btn btn-primary" href="/BTP/src/blog/stories.php"> Cancel </a>
                    </div>
                </div> 
            </form>
		</div>
	</div>
</div>


<?php
// _________________________________FOOTER_______________________________
	include(BASE_URL.'/src/header/footer.php'); // Includes Script
// _________________________________FOOTER_______________________________
?>
