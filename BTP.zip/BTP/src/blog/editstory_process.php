<?php

$error='';
$message='';

if(isset($_GET['pid'])){
		$pid = $_GET['pid'];
	}else{
		header("Location: /BTP/pagenotfound.php");
	}

// BEFORE SUBMITTING THE CHANGES...

	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}
	$sql = "select * from blog where pid='".$pid."'";
	$result = mysqli_query($conn, $sql);
	$row = $result->fetch_assoc();

	$id=$row['id'];
	/// PROTECTION : SQL INJECTION !
	if($_SESSION['user_id']==$id || $_SESSION['user_level']==3 || $_SESSION['user_level']==2 || $_SESSION['user_level']==5 ){
		;
	}
	else{
		header("Location: /BTP/pagenotfound.php");
	}

	$privacy=$row['privacy'];
	$title=$row['title'];
	$post=$row['post'];
	$status=$row['status'];
 
	mysqli_close($conn); // Closing Connection


// AFTER SUBMITING THE CHANGES...

// ______________________________________________ SAVE AS DRAFT __________________________________________________
if (isset($_POST['submit_draft'])) {

		if (empty($_POST['title']) || empty($_POST['story'])) {
			$error = "Invalid or Empty Inputs!";
		}
	

	$title=$_POST['title'];
	$post=$_POST['story'];
	$story2=$_POST['story'];
	$privacy=$_POST['privacy'];

	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}

	$title = stripslashes($title);
	$story2 = stripslashes($story2);
	$title = mysqli_real_escape_string($conn, $title);
	$story2 = mysqli_real_escape_string($conn, $story2);
	
	$sql= "UPDATE blog set title='".$title."', post='".$story2."', privacy='".$privacy."', status=0, dateofpublish=NOW() where pid='".$pid."'";

	if (mysqli_query($conn, $sql)) {
		$message = "Draft Saved Successfully!";

	}else{
		$error ="Unable to Process Your Story, Please Try Again Later!";
	}
mysqli_close($conn); // Closing Connection
}


// _________________________________________________ PUBLISH __________________________________________________
if (isset($_POST['submit_publish'])) {

		if (empty($_POST['title']) || empty($_POST['story'])) {
			$error = "Invalid or Empty Inputs!";
		}
	

	$title=$_POST['title'];
	$post=$_POST['story'];
	$story2=$_POST['story'];
	$privacy=$_POST['privacy'];

	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}

	$title = stripslashes($title);
	$story2 = stripslashes($story2);
	$title = mysqli_real_escape_string($conn, $title);
	$story2 = mysqli_real_escape_string($conn, $story2);
	
	$sql= "UPDATE blog set title='".$title."', post='".$story2."', privacy='".$privacy."', status=1, dateofpublish=NOW() where pid='".$pid."'";

	if (mysqli_query($conn, $sql)) {
		$message = "Draft Saved and Sent for Review!";

	}else{
		$error ="Unable to Process Your Story, Please Try Again Later!";
	}
mysqli_close($conn); // Closing Connection
}


?>