<?php
$error=NULL;
$message=NULL;

// ______________________________________________ SAVE AS DRAFT __________________________________________________
if (isset($_POST['submit_draft'])) {

		if (empty($_POST['title']) || empty($_POST['story'])) {
			$error = "Invalid or Empty Inputs!";
		}
	

	$title=$_POST['title'];
	$story=$_POST['story'];
	$story2=$_POST['story'];
	$privacy=$_POST['privacy'];

	$id = $_SESSION['user_id'];

	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}

	$title = stripslashes($title);
	$story2 = stripslashes($story2);
	$title = mysqli_real_escape_string($conn, $title);
	$story2 = mysqli_real_escape_string($conn, $story2);
	
	$sql= "insert into blog (id, privacy,title, post,status, dateofpublish)
		VALUES (".$id.",".$privacy.",'".$title."','".$story2."',0,NOW())";

	if (mysqli_query($conn, $sql)) {
		$message = "Draft Saved Successfully!";

	}else{
		$error ="Unable to Process Your Story, Please Try Again Later!";
	}
mysqli_close($conn); // Closing Connection
}


// _________________________________________________ PUBLISH __________________________________________________
if (isset($_POST['submit_publish'])) {

		if (empty($_POST['title']) || empty($_POST['story'])) {
			$error = "Invalid or Empty Inputs!";
		}
	

	$title=$_POST['title'];
	$story=$_POST['story'];
	$story2=$_POST['story'];
	$privacy=$_POST['privacy'];

	$id = $_SESSION['user_id'];

	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}

	$title = stripslashes($title);
	$story2 = stripslashes($story2);
	$title = mysqli_real_escape_string($conn, $title);
	$story2 = mysqli_real_escape_string($conn, $story2);
	
	$sql= "insert into blog (id, privacy,title, post,status, dateofpublish)
		VALUES (".$id.",".$privacy.",'".$title."','".$story2."',1,NOW())";

	if (mysqli_query($conn, $sql)) {
		$message = "Draft Saved and Sent for Review!";

	}else{
		$error ="Unable to Process Your Story, Please Try Again Later!";
	}
mysqli_close($conn); // Closing Connection
}


?>