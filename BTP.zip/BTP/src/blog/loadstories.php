<?php
	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	$id = $_SESSION['user_id'];
	$level = $_SESSION['user_level'];

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}

	if($level==1||$level==2){
		$sql = "select * from blog where id='".$id."' order by pid desc";
	}else{
		$sql = "select * from blog where (status=1 or status =2) or (id='".$id."') order by pid desc";
	}
	
	
	$result = mysqli_query($conn, $sql);

	$no_of_stories = $result->num_rows;

	for($j=1;$j<=$no_of_stories;$j++){

		$row = $result->fetch_assoc();
		$title[$j] = $row['title'];
		$userid[$j] = $row['id'];
		$statno[$j] = $row['status'];

		if($row['status']==0){
			$status[$j] = "Draft Saved";
		}else if($row['status']==1){
			$status[$j] = "Pending Review";
		}else if($row['status']==2){
			$status[$j] = "Published";
		}

		$privacy[$j] = $row['privacy'];

		$date[$j] = $row['dateofpublish'];
		$pid[$j] = $row['pid'];
	}

?>