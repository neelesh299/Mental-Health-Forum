<?php

$error='';
$message='';

if(isset($_GET['cid']) && isset($_GET['type'])){
		$cid = $_GET['cid'];
		$type = $_GET['type'];
	}else{
		header("Location: /BTP/pagenotfound.php");
	}

// BEFORE SUBMITTING THE CHANGES...

	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}

	if($type==0){			// Report Comment - Load Data

		$sql = "SELECT * FROM comments WHERE cid=".$cid."";
		$result = mysqli_query($conn, $sql);
		$row = $result->fetch_assoc();
		$content = $row['comments'];

		$uid = $_SESSION['user_id'];


	}else if($type==1){		// Report Post - Load Data
		$sql = "SELECT * FROM blog WHERE pid=".$cid."";
		$result = mysqli_query($conn, $sql);
		$row = $result->fetch_assoc();
		$content = $row['title'];

		$uid = $_SESSION['user_id'];

	}

	// ___________________________________ AFTER SUBMIT _________________________________

	if (isset($_POST['submit_report'])) {
		$problem = $_POST['problem'];
		
		$sql2 = "INSERT INTO report (type,cid,content,problem,uid)
				VALUES (".$type.",".$cid.",'".$content."','".$problem."',".$uid.")";

		if (mysqli_query($conn, $sql2)) {
			$message = "Content Reported Successfully!";
		}else{
			$error ="Unable to Process Your Request, Please Try Again Later!";
		}
	}



	mysqli_close($conn); // Closing Connection

?>