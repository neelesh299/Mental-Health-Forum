<?php
	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	$id = $_SESSION['user_id'];

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}

	$sql = "SELECT * FROM report order by rid desc";
	
	
	$result = mysqli_query($conn, $sql);

	$no_of_reports = $result->num_rows;

	for($j=1;$j<=$no_of_reports;$j++){

		$row = $result->fetch_assoc();
		$rid[$j] = $row['rid'];
		$uid[$j] = $row['uid'];
		$cid[$j] = $row['cid'];
		$data[$j] = $row['content'];
		$problem[$j] = $row['problem'];

		if($row['type']==0){
			$type[$j] = "Comment";
		}else if($row['type']==1){
			$type[$j] = "Story Post";
		}
	} // end of loop

	if(isset($_POST['submit'])){
		$pid= $_POST['submit'];
		$sql = "Delete from report where rid='".$pid."'";

		if (mysqli_query($conn, $sql)) {
			header("Location: /BTP/src/report/viewreports.php");
		}else{
			$error_delete = "Unable to Delete Complaint, Please try again later!";
		}
	}

	mysqli_close($conn); // Closing Connection
?>