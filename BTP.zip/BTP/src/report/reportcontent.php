<?php
session_start();
include('reportcontent_process.php'); // Includes Script
//__________________________HEADER __________________________________________________________
define('BASE_URL', $_SERVER["DOCUMENT_ROOT"].'/BTP');
include(BASE_URL.'/src/header/header.php'); // INCLUDE HEADER FILE
//____________________________HEADER_________________________________________________________


    if(isset($_SESSION['login_user'])){
        ;
    }
    else{
        header("location: /BTP/src/user/login_form.php");
    }
?>


<!-- ...............................................DISPLAY PART........................... -->
<div class="container-fluid" style="margin-top:50px">
    <h1>Report:</h1><br>
    <div class="row">
        <div class="col-md-1">
            <!-- Sidebar -->
        </div>
                    
                                    
        <div class="col-md-10">
            <form class="form-horizontal" action="" method="post">
                
                <div class="form-group">
                    <label class="control-label col-sm-2" >Content Type :</label>
                    <div class="col-sm-8">

                        <h5>
                            <?php 
                                if($type==0){
                                    echo "Comment";
                                }else if($type==1){
                                    echo "Story Post";
                                }
                            ?>   
                        </h5>
                    </div>
                </div>

                <br>
                <div class="form-group">
                    <label class="control-label col-sm-2">Content :</label>
                    <div class="col-sm-8">
                        <h5><?php echo $content;?></h5>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-2">Content :</label>
                    <div class="col-sm-8">
                        <textarea class="form-control" required name="problem" rows="4" placeholder="Report Your Issue Here!"></textarea>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-8">
                        
                        <!-- .......................................................... -->
                        <?php if($error==NULL) {?>
                        <div> 
                            <?php } else {?>
                        <div style="margin-top: 5px;" class="alert alert-danger alert-dismissible in">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <?php } ?>
                        <?php echo $error; ?>
                        </div>
                        <!-- .......................................................... -->
                        <?php if($message==NULL) {?>
                        <div> 
                            <?php } else {?>
                        <div style="margin-top: 5px;" class="alert alert-success alert-dismissible in">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <?php } ?>
                        <?php echo $message; ?>
                        </div>
                        <!-- .......................................................... -->
                        <?php
                        if($message==NULL){ 
                        ?>
                        <input style="width=100%;" class="btn btn-danger" name="submit_report" type="submit" value=" Report ">
                        <?php } ?>
                        <a class="btn btn-primary" href="/BTP/src/blog/blog.php">Back to Blog</a>
                    </div>
                </div>  
            </form>
            
        </div>

        <div class="col-md-1">
            <!-- Sidebar -->
        </div>
    </div>
</div>

<?php
// _________________________________FOOTER_______________________________
    include(BASE_URL.'/src/header/footer.php'); // Includes Script
// _________________________________FOOTER_______________________________
?>
