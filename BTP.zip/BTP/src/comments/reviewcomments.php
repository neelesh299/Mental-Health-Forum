
<?php
session_start();
//__________________________HEADER __________________________________________________________
define('BASE_URL', $_SERVER["DOCUMENT_ROOT"].'/BTP');
include(BASE_URL.'/src/header/header.php'); // INCLUDE HEADER FILE
//____________________________HEADER_________________________________________________________
include('loadcomments.php');

	if(isset($_SESSION['login_user'])){
		;
	}
	else{
		header("location: /BTP/src/user/login_form.php");
	}

?>

<div class="container-fluid" style="margin-top:50px">
	<div class="row">
		<div class="col-md-2 sidenav ">
			<!-- Sidebar -->
			<h4>Happinezz</h4>
      <ul class="nav nav-pills nav-stacked">
        <li><a href="http://localhost/BTP/src/user/profile.php">Dashboard</a></li>
        <li><a href="http://localhost/BTP/src/user/update_profile.php">Update Profile</a></li>
        <li><a href="http://localhost/BTP/src/account_recovery/account_settings.php">Account Settings</a></li>
        <li><a href="http://localhost/BTP/src/blog/stories.php">Stories</a></li>
        <li class="active"><a href="http://localhost/BTP/src/comments/reviewcomments.php">Comments</a></li>
        <li><a href="http://localhost/BTP/src/form/loadforms.php">Psych-Tests</a></li>
        <li><a href="http://localhost/BTP/src/user/community.php">Community</a></li>
        <?php if($_SESSION['user_level']==5) { ?> 
        <li><a href="http://localhost/BTP/src/admin/view_logs.php">View Logs</a></li>
      	<li><a href="http://localhost/BTP/src/admin/manage_users.php">Manage Users</a></li>
        <li><a href="http://localhost/BTP/src/report/viewreports.php">Complaints</a></li>
        <li><a href="http://localhost/BTP/src/admin/view_form_response.php">User Reports</a></li>
        <?php } ?>
      </ul><br>
		</div>
		<div class="col-md-2">
		</div>
		<div class="col-md-10">	
			<h2>Stories: &nbsp;&nbsp;<a class="btn btn-success" href="/BTP/src/blog/newstory.php">Review Comments</a></h2>
			
			<div class="table-responsive" style="width:100%;overflow:auto; max-height:480px;"> 
                <form class="form-horizontal" action="" method="post">
        		<table class="table table-sm table-hover table-bordered table-striped">
            	<thead>
            		<tr>
                		<th>Sr. No.</th>
                		<?php if($level==3||$level==4||$level==5){
                			echo '<th>User ID</th>';
                		}?>
                		<th>Comment</th>
                		<th>Status</th>
                		<?php if($level==3||$level==4||$level==5){
                            echo '<th>Story Title</th>';
                			echo '<th>Change Status</th>';
                		}?>
                        <th>Delete</th>
            		</tr>
            	</thead>
            	<tbody>
            		<?php 
                		for($j=1;$j<=$no_of_comments;$j++){ 
                			echo '<tr>
                        		<td>'.$j.'</td>';
                        		if($level==3||$level==4||$level==5){
                        			echo '<td>'.$cuid[$j].'</td>';
                        		}
                       		echo '
                        		<td>'.$cdata[$j].'</td>
                        		<td>'.$cstat[$j].'</td>';
                        		if($level==3||$level==4||$level==5){
                                    echo '<td>'.$ptitle[$j].'</td>';
                                    echo '<td> <a class="btn btn-primary center-block" href="/BTP/src/comments/editcommentstatus.php?cid='.$cid[$j].'">Edit Status</a> </td>';
                        		}
                       		echo '<td> <button class="btn btn-danger center-block" name="submit" value='.$cid[$j].' type="submit">Delete</button> </td>
                       			</tr>';
                		}
              		?>
            	</tbody>
         		</table>
                </form>
        	</div>
		</div>
	</div>
</div>


<?php
// _________________________________FOOTER_______________________________
	include(BASE_URL.'/src/header/footer.php'); // Includes Script
// _________________________________FOOTER_______________________________
?>
