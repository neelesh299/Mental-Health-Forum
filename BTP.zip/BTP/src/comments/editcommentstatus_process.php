<?php

$error='';
$message='';

if(isset($_GET['cid'])){
		$cid = $_GET['cid'];
	}else{
		header("Location: /BTP/pagenotfound.php");
	}

// BEFORE SUBMITTING THE CHANGES...

	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}

	$sql = "select * from comments where cid='".$cid."'";
	$result = mysqli_query($conn, $sql);
	$row = $result->fetch_assoc();

	

	/// PROTECTION : SQL INJECTION !
	if($_SESSION['user_level']==5){
		;
	}
	else{
		header("Location: /BTP/pagenotfound.php");
	}

	$cdata=$row['comments'];
	$status = $row['stat'];
	$cpid=$row['pid'];
 	
 	$sql2 = "select * from blog where pid='".$cpid."'";
	$result2 = mysqli_query($conn, $sql2);
	$row2 = $result2->fetch_assoc();
	$title= $row2['title'];

	mysqli_close($conn); // Closing Connection


// AFTER SUBMITING THE CHANGES...


// _________________________________________________ PUBLISH __________________________________________________
if (isset($_POST['submit_publish'])) {
	

	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}

	
	$sql= "UPDATE comments set stat=1 where cid='".$cid."'";

	if (mysqli_query($conn, $sql)) {
		$message = "Comment Published Successfully!";
		$status =1;
	}else{
		$error ="Unable to Process Your Request, Please Try Again Later!";
	}
mysqli_close($conn); // Closing Connection
}

// _________________________________________________ PENDING REVIEW __________________________________________________
if (isset($_POST['submit_pending'])) {
	

	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}

	
	$sql= "UPDATE comments set stat=0 where cid='".$cid."'";

	if (mysqli_query($conn, $sql)) {
		$message = "Comment left for Pending Review!";
		$status =0;
	}else{
		$error ="Unable to Process Your Request, Please Try Again Later!";
	}
mysqli_close($conn); // Closing Connection
}


?>