<?php
	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	$id = $_SESSION['user_id'];
	$level = $_SESSION['user_level'];

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}

	if($level==1||$level==2){
		$sql = "select * from comments where uid='".$id."' order by cid desc";
	}else{
		$sql = "select * from comments order by cid desc";
	}
	
	
	$result = mysqli_query($conn, $sql);

	$no_of_comments = $result->num_rows;

	for($j=1;$j<=$no_of_comments;$j++){

		$row = $result->fetch_assoc();
		$cid[$j] = $row['cid'];
		$cuid[$j] = $row['uid'];
		$cpid[$j] = $row['pid'];
		$cdata[$j] = $row['comments'];

		if($row['stat']==0){
			$cstat[$j] = "Pending Review";
		}else if($row['stat']==1){
			$cstat[$j] = "Published";
		}

		$sql2 = "select * from blog where pid ='".$cpid[$j]."'";
		$result2 = mysqli_query($conn, $sql2);
		$row2 = $result2->fetch_assoc();
		$ptitle[$j] = $row2['title'];
	} // end of loop


	if(isset($_POST['submit'])){
		$cid= $_POST['submit'];
		$sql = "Delete from comments where cid='".$cid."'";

		if (mysqli_query($conn, $sql)) {
			header("Location: /BTP/src/comments/reviewcomments.php");
		}else{
			$error_delete = "Unable to Delete Comment, Please try again later!";
		}
	}

	mysqli_close($conn); // Closing Connection
?>