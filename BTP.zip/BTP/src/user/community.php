<?php
session_start();


//include('community_process.php'); // Includes Login Script
//__________________________HEADER __________________________________________________________
define('BASE_URL', $_SERVER["DOCUMENT_ROOT"].'/BTP');
include(BASE_URL.'/src/header/header.php'); // INCLUDE HEADER FILE
//____________________________HEADER_________________________________________________________

	if(isset($_SESSION['login_user'])){
		;
	}
	else{
		header("location: /BTP/src/user/login_form.php");
	} 

?>


<div class="container-fluid" style="margin-top:50px">
	<div class="row">	
		<div class="col-md-2 sidenav ">
			<!-- Sidebar -->
			<h4>Happinezz</h4>
      <ul class="nav nav-pills nav-stacked">
        <li ><a href="http://localhost/BTP/src/user/profile.php">Dashboard</a></li>
        <li><a href="http://localhost/BTP/src/user/update_profile.php">Update Profile</a></li>
        <li><a href="http://localhost/BTP/src/account_recovery/account_settings.php">Account Settings</a></li>
        <li><a href="http://localhost/BTP/src/blog/stories.php">Stories</a></li>
        <li><a href="http://localhost/BTP/src/comments/reviewcomments.php">Comments</a></li>
        <li><a href="http://localhost/BTP/src/form/loadforms.php">Psych-Tests</a></li>
        <li class="active"><a href="http://localhost/BTP/src/user/community.php">Community</a></li>
        <?php if($_SESSION['user_level']==5) { ?> 
        <li><a href="http://localhost/BTP/src/admin/view_logs.php">View Logs</a></li>
      	<li><a href="http://localhost/BTP/src/admin/manage_users.php">Manage Users</a></li>
        <li><a href="http://localhost/BTP/src/report/viewreports.php">Complaints</a></li>
        <li><a href="http://localhost/BTP/src/admin/view_form_response.php">User Reports</a></li>
        <?php } ?>
      </ul><br>
			
		</div>
		<div class="col-md-2">
		</div>
		<div class="col-md-10">
			<div class="rownew">
			<?php
			$servername = "localhost";
			$user = "root";
			$pass = "";
			$dbname = "btp_project";

			// Create connection
			$conn = mysqli_connect($servername, $user, $pass, $dbname);
			// Check connection
			if (!$conn) {
			    die("Connection failed: " . mysqli_connect_error());
			}

			$sql = "select * from user_login where level=1";
			$result = mysqli_query($conn, $sql);

			if ($result->num_rows > 0) {
				while($row = $result->fetch_assoc()) {
					$id=$row['id'];

					$sql2 = "select * from user_data where id='$id'";
					$result2 = mysqli_query($conn, $sql2);
					$row2 = $result2->fetch_assoc();

					$firstname = $row2['firstname'];
					$lastname = $row2['lastname'];
					$avatar = $row2['avatar'];
					$about = $row2['about'];

					echo '	<div class="colnew">
							<div class="card">
							<div class="card">
								<img src="'.$avatar.'" style="width:70%">
								<h4>'.$firstname.' '.$lastname.'</h4>
								<br>
							</div>
							</div>
						  	</div>';
		    	}
			}
			?>
			</div>
		</div>
		
	</div>
</div>

<?php
// _________________________________FOOTER_______________________________
	include(BASE_URL.'/src/header/footer.php'); // Includes Script
// _________________________________FOOTER_______________________________
?>
