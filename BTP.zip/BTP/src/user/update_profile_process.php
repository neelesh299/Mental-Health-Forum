<?php
//session_start(); 
$error='';
$message='';
$error_img='';
$message_img='';
$id = $_SESSION['user_id'];
$username = $_SESSION['login_user'];

// BEFORE SUBMITTING THE CHANGES...

	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}
	$sql = "select * from user_data where id='".$id."'";
	$result = mysqli_query($conn, $sql);
	$row = $result->fetch_assoc();

	$firstname=$row['firstname'];
	$lastname=$row['lastname'];
	$about=$row['about'];
	$avatar=$row['avatar'];
	$email  =$row['email'];
 
	mysqli_close($conn); // Closing Connection


// AFTER SUBMITING THE CHANGES...
if (isset($_POST['submit'])) {
	
	$firstname=$_POST['firstname'];
	$lastname=$_POST['lastname'];
	$about2=$_POST['about'];
	$about=$_POST['about'];
	$email  =$_POST['email'];
	
	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}

	$about2 = mysqli_real_escape_string($conn, $about2);
	
	$sql = "UPDATE user_data SET firstname='".$firstname."', lastname='".$lastname."', about='".$about2."', email='".$email."' where id='".$id."'";
	
	
	if (mysqli_query($conn, $sql)) {
		$message = "Changes Saved Successfully!";
	}else{
		$error = "Error: " . $sql . "<br>" . mysqli_error($conn);
	}

	mysqli_close($conn); // Closing Connection
}



// Image Processing ...

if(isset($_POST["submit_image"])) {

$target_dir = "/opt/lampp/htdocs/BTP/assets/avatars/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

// Check if file already exists
/*if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}*/
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    $error_img= "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    ;
// if everything is ok, try to upload file
} else {
	
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_dir .$username.".".$imageFileType)) {
        $message_img= "The image has been uploaded.";


        // Create connection
		$conn = mysqli_connect($servername, $user, $pass, $dbname);
		// Check connection
		if (!$conn) {
		    die("Connection failed: " . mysqli_connect_error());
		}
	
		$sql = "UPDATE user_data SET avatar='/BTP/assets/avatars/".$username.".".$imageFileType."' where id='".$id."'";
		mysqli_query($conn, $sql);
		mysqli_close($conn); // Closing Connection
		$avatar="/BTP/assets/avatars/".$username.".".$imageFileType;

    } else {
        $error_img= "Sorry, there was an error uploading your file.";
    }
}
}

?>
