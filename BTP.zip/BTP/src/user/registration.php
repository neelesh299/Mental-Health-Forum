<?php
include('insert_user.php'); // Includes Login Script

if(isset($_SESSION['login_user'])){
header("location: /BTP/src/user/profile.php");
}
//__________________________HEADER __________________________________________________________
define('BASE_URL', $_SERVER["DOCUMENT_ROOT"].'/BTP');
include(BASE_URL.'/src/header/header.php'); // INCLUDE HEADER FILE
//____________________________HEADER_________________________________________________________
?>

<div class="container-fluid" style="margin-top:50px">
	<div class="row">
		<div class="col-md-2">
			<!-- Sidebar -->
		</div>
		<div class="col-md-10">
			<h1>Create an Account</h1><br>
			<form class="form-horizontal" action="" method="post">
				
				<div class="form-group">
					<label class="control-label col-sm-4" >Username :</label>
					<div class="col-sm-6">
						<input class="form-control" id="name" name="username" placeholder="username" type="text">
					</div>
				</div>

				<br>
				<div class="form-group">
					<label class="control-label col-sm-4">Password :</label>
					<div class="col-sm-6">
						<input class="form-control" id="password" name="password" placeholder="**********" type="password">
					</div>
				</div>
				<!-- USER LEVEL IS 1 (PUBLIC USER) BY DEFAULT !!! -->
				<br>
				<div class="form-group">
					<label class="control-label col-sm-4">Select a Security Question:</label>
					<div class="col-sm-6">
						<select class="form-control" name="question">
							<option value="What Is your favorite book?">What Is your favorite book?</option>
							<option value="What was the name of your first/current/favorite pet?">What was the name of your first/current/favorite pet?</option>
							<option value="What was the first company that you worked for?">What was the first company that you worked for?</option>
							<option value="What is your favorite food?">What is your favorite food?</option>
							<option value="Where is your favorite place to vacation?">Where is your favorite place to vacation?</option>
							<option value="What city were you born in?">What city were you born in?</option>
						</select>
					</div>
				</div>
				

				<div class="form-group">
					<label class="control-label col-sm-4">Answer:</label>
					<div class="col-sm-6">
						<input class="form-control" id="name" name="answer" placeholder="Answer" type="text">
					</div>
				</div>	

				<div class="form-group">
    				<div class="col-sm-offset-4 col-sm-6">
						
						<!-- .......................................................... -->
						<?php if($error==NULL) {?>
						<div> 
							<?php } else {?>
						<div style="margin-top: 5px;" class="alert alert-danger alert-dismissible in">
							<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							<?php } ?>
						<?php echo $error; ?>
						</div>
						<!-- .......................................................... -->
						<?php if($error1==NULL) {?>
						<div> 
							<?php } else {?>
						<div style="margin-top: 5px;" class="alert alert-danger alert-dismissible in">
							<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							<?php } ?>
						<?php echo $error1; ?>
						</div>
						<!-- .......................................................... -->
						<?php if($error2==NULL) {?>
						<div> 
							<?php } else {?>
						<div style="margin-top: 5px;" class="alert alert-danger alert-dismissible in">
							<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							<?php } ?>
						<?php echo $error2; ?>
						</div>
						<!-- .......................................................... -->
						<?php if($message==NULL) {?>
						<div> 
							<?php } else {?>
						<div style="margin-top: 5px;" class="alert alert-success alert-dismissible in">
							<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							<?php } ?>
						<?php echo $message; ?>
						</div>
						<!-- .......................................................... -->
						<input style="width=100%;" class="btn btn-success" name="submit" type="submit" value=" Register "><br>
						<h4><small><a href="/BTP/src/user/login_form.php"> Already have an Account? </a></small></h4>
					</div>
				</div>	
			</form>
		</div>
	</div>
</div>




<?php
// _________________________________FOOTER_______________________________
	include(BASE_URL.'/src/header/footer.php'); // Includes Script
// _________________________________FOOTER_______________________________
?>
