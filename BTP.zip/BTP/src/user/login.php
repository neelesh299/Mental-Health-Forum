<?php
session_start(); 
$error=NULL; 
if (isset($_POST['submit'])) {
	if (empty($_POST['username']) || empty($_POST['password'])) {
		$error = "Invalid or Incomplete Input!";
	}
	else{
	
	$username=$_POST['username'];
	$password=$_POST['password'];
	
	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}
	
	$username = stripslashes($username);
	$password = stripslashes($password);
	$username = mysqli_real_escape_string($conn, $username);
	$password = mysqli_real_escape_string($conn, $password);
	
	$sql = "select * from user_login where user_name = '$username' and user_password='$password'";
	$result = mysqli_query($conn, $sql);
	
	/*if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			echo "id: " . $row["id"]. " - Name: " . $row["user_name"]."<br>";
    	}
	}*/

	if (mysqli_num_rows($result) == 1) {
		$row = $result->fetch_assoc();
		$_SESSION['user_id']=$row['id'];
		$_SESSION['login_user']=$row["user_name"]; 
		$_SESSION['user_level']=$row["level"];

		// MAINTAINING LOGS FOR THE LOGIN TIME AND DATE INFORMATION !
		$logsql= "insert into log_user (id,login,logout)
		VALUES (".$row['id'].",NOW(),NULL )";
	

		if(mysqli_query($conn, $logsql)){
			header("location: profile.php");
		}
		
	} else {
		$error = "Username or Password is Wrong! Please check your credentials!";
	}
	mysqli_close($conn); // Closing Connection
	}
}
?>
