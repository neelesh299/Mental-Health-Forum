<?php
//session_start(); 
$error=NULL;
$error1=NULL;
$error2=NULL;
$message=NULL;

if (isset($_POST['submit'])) {
	if (empty($_POST['username']) || empty($_POST['password'])) {
		$error1 = "Username or Password is invalid";
	}
	if (empty($_POST['question']) || empty($_POST['answer'])) {
		$error2 = "Security question or Answer is invalid";
	}
	else{
	
	$username=$_POST['username'];
	$password=$_POST['password'];
	$question=$_POST['question'];
	$answer  =$_POST['answer'];
	
	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}
	
	$username = stripslashes($username);
	$password = stripslashes($password);
	$username = mysqli_real_escape_string($conn, $username);
	$password = mysqli_real_escape_string($conn, $password);
	
	$sql = "select * from user_login where user_name = '$username'";
	$result = mysqli_query($conn, $sql);
	
	if ($result->num_rows > 0) {
		$error = "Username already exists! Please choose a different username!";
	}else{
		$sql= "insert into user_login (user_name, user_password, level, security_ques, ans)
		VALUES ('".$username."','".$password."', 1,'".$question."','".$answer."')";

		if (mysqli_query($conn, $sql)) {
    		$message = "New Account created successfully<br> Login to access your account! ";

    		$query = "select * from user_login where user_name = '$username'";
    		$result2 = mysqli_query($conn, $query);
			$row = $result2->fetch_assoc();
			$id=$row['id'];

			// ADDING DEFAULT PANDA IMAGE and PROFILE DATA in USER_DATA TABLE !!!!
			$default_img = "/opt/lampp/htdocs/BTP/assets/avatars/panda.jpg";
			$new_img = "/opt/lampp/htdocs/BTP/assets/avatars/".$username.".jpg";
			copy($default_img, $new_img);
			$query = "INSERT INTO user_data (id,firstname,lastname,avatar,about,email)
			VALUES (".$id.",'John','Doe','/BTP/assets/avatars/".$username.".jpg','About Me- I am Positive !','email ID')";
			mysqli_query($conn, $query);

		} else {
    		$messgae = "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
	}

	mysqli_close($conn); // Closing Connection
	}
}
?>
