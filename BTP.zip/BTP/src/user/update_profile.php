<?php
session_start(); 
include('update_profile_process.php'); // Includes Login Script

if(isset($_SESSION['login_user'])){
	;
}else{
	header("location: /BTP/src/user/login_form.php");
}

//__________________________HEADER __________________________________________________________
define('BASE_URL', $_SERVER["DOCUMENT_ROOT"].'/BTP');
include(BASE_URL.'/src/header/header.php'); // INCLUDE HEADER FILE
//____________________________HEADER_________________________________________________________
?>


<div class="container-fluid" style="margin-top:50px">
	<div class="row">
		<div class="col-md-2 sidenav ">
			<!-- Sidebar -->
			<h4>Happinezz</h4>
      <ul class="nav nav-pills nav-stacked">
        <li><a href="http://localhost/BTP/src/user/profile.php">Dashboard</a></li>
        <li class="active"><a href="http://localhost/BTP/src/user/update_profile.php">Update Profile</a></li>
        <li><a href="http://localhost/BTP/src/account_recovery/account_settings.php">Account Settings</a></li>
        <li><a href="http://localhost/BTP/src/blog/stories.php">Stories</a></li>
        <li><a href="http://localhost/BTP/src/comments/reviewcomments.php">Comments</a></li>
        <li><a href="http://localhost/BTP/src/form/loadforms.php">Psych-Tests</a></li>
        <li><a href="http://localhost/BTP/src/user/community.php">Community</a></li>
        <?php if($_SESSION['user_level']==5) { ?> 
        <li><a href="http://localhost/BTP/src/admin/view_logs.php">View Logs</a></li>
		<li><a href="http://localhost/BTP/src/admin/manage_users.php">Manage Users</a></li>
        <li><a href="http://localhost/BTP/src/report/viewreports.php">Complaints</a></li>
        <li><a href="http://localhost/BTP/src/admin/view_form_response.php">User Reports</a></li>
        <?php } ?>
      </ul><br>
		</div>
		<div class="col-md-2">
		</div>
		<div class="col-md-6">	
			<h2>Update Profile</h2><br>

			<form action="" class="form-horizontal" method="post">
				<div class="form-group">
					<label class="control-label col-sm-4">First Name:</label>
					<div class="col-sm-8">
						<?php echo '<input class="form-control" id="name" name="firstname" value="'.$firstname.'" type="text">';?>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-4">Last Name:</label>
					<div class="col-sm-8">
						<?php echo '<input class="form-control" id="name" name="lastname" value="'.$lastname.'" type="text">';?>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-4">About:</label>
					<div class="col-sm-8">
						<?php echo '<textarea class="form-control" name="about" rows="5" cols="50" >'.$about.'</textarea>';?>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-4">Email:</label>
					<div class="col-sm-8">
						<?php echo '<input class="form-control" id="name" name="email" value="'.$email.'" type="text">';?>
					</div>
				</div>
				<div class="form-group">
    				<div class="col-sm-offset-4 col-sm-8">
    					<?php if($error==NULL) {?>
							<div> 
						<?php } else {?>
							<div style="margin-top: 5px;" class="alert alert-danger alert-dismissible in">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						<?php } ?>
								<?php echo $error; ?>
							</div>
						<?php if($message==NULL) {?>
							<div> 
						<?php } else {?>
							<div style="margin-top: 5px;" class="alert alert-success alert-dismissible in">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						<?php } ?>
								<?php echo $message; ?>
							</div>
    					<input name="submit" class="btn btn-success" type="submit" value=" Save Changes ">
    				</div>
    			</div>
			</form>
			<!-- ////////////////////////////////////////////////////////////////////////////// -->
			
		</div>
		<div class="col-md-4">
			<br>
			<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
				<div class="form-group">
					<div class="col-sm-12" >
					<h4>Profile Picture</h4><br>
					<?php echo '<img src="'.$avatar.'" height="150" width="150">'; ?>
					</div>
				</div>
			    <div class="form-group" >
					<h5>&nbsp;&nbsp;&nbsp;&nbsp;Select new profile picture:</h5>
					<div class="col-sm-12">
						<br>
						<input class="btn btn-default" type="file" name="fileToUpload" id="fileToUpload"><br>
						<?php if($error_img==NULL) {?>
							<div> 
						<?php } else {?>
							<div style="margin-top: 5px;" class="alert alert-danger alert-dismissible in">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						<?php } ?>
								<?php echo $error_img; ?>
							</div>
						<?php if($message_img==NULL) {?>
							<div> 
						<?php } else {?>
							<div style="margin-top: 5px;" class="alert alert-success alert-dismissible in">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						<?php } ?>
								<?php echo $message_img; ?>
							</div>
			    		<input class="btn btn-success" type="submit" value="Upload Image" name="submit_image">
					</div>
				</div>
			</form>
			<!-- ////////////////////////////////////////////////////////////////////////////// -->

		</div>
	</div>
</div>


<?php
// _________________________________FOOTER_______________________________
	include(BASE_URL.'/src/header/footer.php'); // Includes Script
// _________________________________FOOTER_______________________________
?>
