<?php
session_start();
	if(isset($_SESSION['login_user'])){
		//record timestamp for evry loaded page!
		$id = $_SESSION['user_id'];
		$servername = "localhost";
		$user = "root";
		$pass = "";
		$dbname = "btp_project";

		// Create connection
		$conn = mysqli_connect($servername, $user, $pass, $dbname);
		// Check connection
		if (!$conn) {
		    die("Connection failed: " . mysqli_connect_error());
		}
		// 	MAINTAINING LOGS FOR LOGOUT TIME AND DATE
		$logsql = "UPDATE log_user SET logout=NOW() where id='".$id."'";
		mysqli_query($conn, $logsql);
	}
if(session_destroy()) // Destroying All Sessions
{
header("Location: /BTP/src/user/login_form.php"); // Redirecting To Home Page
}
?>