<?php
include('login.php'); // Includes Login Script

if(isset($_SESSION['login_user'])){
header("location: /BTP/src/user/profile.php");
}

//__________________________HEADER __________________________________________________________
define('BASE_URL', $_SERVER["DOCUMENT_ROOT"].'/BTP');
include(BASE_URL.'/src/header/header.php'); // INCLUDE HEADER FILE
//____________________________HEADER_________________________________________________________
?>


<div class="container-fluid" style="margin-top:50px">
	
	<div class="row">
		<div class="col-md-3">
			<!-- Sidebar -->
		</div>
		<div class="col-md-9">
			<br>
			<h1>Login</h1><br>
			<form action="" class="form-horizontal" method="post">
				<div class="form-group">
					<label  class="control-label col-sm-2" >Username :</label>
					<div class="col-sm-4">
						<input class="form-control"  id="name" name="username" placeholder="username" type="text"><br>
					</div>
				</div>
				<div class="form-group">
					<label  class="control-label col-sm-2">Password :</label>
					<div class="col-sm-4">
						<input class="form-control" id="password" name="password" placeholder="**********" type="password"><br>
					</div>
				</div>
				<div class="form-group">
    				<div class="col-sm-offset-2 col-sm-4">
						
						<?php if($error==NULL) {?>
							<div> 
						<?php } else {?>
							<div style="margin-top: 5px;" class="alert alert-danger alert-dismissible in">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						<?php } ?>
								<?php echo $error; ?>
							</div>
						<input style="width=100%;" class="btn btn-success" name="submit" type="submit" value=" Login "><br>
						<h4><small><a href="/BTP/src/account_recovery/recover_pass.php"> Forgot Password? </a></small></h4>
						<h4><small><a href="/BTP/src/user/registration.php"> Create an Account </a></small></h4>
					</div>
				</div>

				
			</form>
		</div>
	</div>
</div>





<?php
//____________________________FOOTER_________________________________________________________
	include(BASE_URL.'/src/header/footer.php'); // Includes Script
//____________________________FOOTER_________________________________________________________
?>
