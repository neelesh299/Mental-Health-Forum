
<?php
session_start();
//__________________________HEADER __________________________________________________________
define('BASE_URL', $_SERVER["DOCUMENT_ROOT"].'/BTP');
include(BASE_URL.'/src/header/header.php'); // INCLUDE HEADER FILE
//____________________________HEADER_________________________________________________________

	if(isset($_SESSION['login_user'])){
		;
	}
	else{
		header("location: /BTP/src/user/login_form.php");
	}

?>

<div class="container-fluid" style="margin-top:50px">
	<div class="row">
		<div class="col-md-2 sidenav ">
			<!-- Sidebar -->
			<h4>Happinezz</h4>
      <ul class="nav nav-pills nav-stacked">
        <li class="active"><a href="http://localhost/BTP/src/user/profile.php">Dashboard</a></li>
        <li><a href="http://localhost/BTP/src/user/update_profile.php">Update Profile</a></li>
        <li><a href="http://localhost/BTP/src/account_recovery/account_settings.php">Account Settings</a></li>
        <li><a href="http://localhost/BTP/src/blog/stories.php">Stories</a></li>
        <li><a href="http://localhost/BTP/src/comments/reviewcomments.php">Comments</a></li>
        <li><a href="http://localhost/BTP/src/form/loadforms.php">Psych-Tests</a></li>
        <li><a href="http://localhost/BTP/src/user/community.php">Community</a></li>
        <?php if($_SESSION['user_level']==5) { ?> 
        <li><a href="http://localhost/BTP/src/admin/view_logs.php">View Logs</a></li>
      	<li><a href="http://localhost/BTP/src/admin/manage_users.php">Manage Users</a></li>
        <li><a href="http://localhost/BTP/src/report/viewreports.php">Complaints</a></li>
        <li><a href="http://localhost/BTP/src/admin/view_form_response.php">User Reports</a></li>
        <?php } ?>
      </ul><br>
		</div>
		<div class="col-md-2">
		</div>
		<div class="col-md-10">	
			<br>
			<div class="panel-group" id="accordion">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title">
							<a data-toggle="collapse" data-parent="#accordion" href="#collapse1">
								1. How to Update Profile ?
							</a>
    					</h4>
    				</div>
    				<div id="collapse1" class="panel-collapse collapse">
      					<div class="panel-body">
      						Click on the Update Profile Tab on the Left Sidebar. Now you can edit your name, profile picture, about, and email address. All these Details are optional!
      					</div>
    				</div>
  				</div>
  				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title">
							<a data-toggle="collapse" data-parent="#accordion" href="#collapse2">
								2. How to change Username/Password ?
							</a>
    					</h4>
    				</div>
    				<div id="collapse2" class="panel-collapse collapse">
      					<div class="panel-body">
      						Click on the Account Settings Tab on the Left Sidebar. Here you can change your username and password. You can also change your security question and its answer.
      					</div>
    				</div>
  				</div>
  				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title">
							<a data-toggle="collapse" data-parent="#accordion" href="#collapse3">
								3. How to Delete your account?
							</a>
    					</h4>
    				</div>
    				<div id="collapse3" class="panel-collapse collapse">
      					<div class="panel-body">
      						Click on the Account Settings Tab on the Left Sidebar. Here you can delete your account permanently. Once deleted, all your account data will be wiped out from our servers. All your published posts, comments, and complaints will also be deleted.
      					</div>
    				</div>
  				</div>
  				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title">
							<a data-toggle="collapse" data-parent="#accordion" href="#collapse4">
								4. What is Account Privacy in the Account Settings ?
							</a>
    					</h4>
    				</div>
    				<div id="collapse4" class="panel-collapse collapse">
      					<div class="panel-body">
      						You can set your account privacy as per your choice, Public Account will be listed in the 'Community' for other users to interact with you. Private Account will only be visible to the moderators of this platform.
      					</div>
    				</div>
  				</div>
  				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title">
							<a data-toggle="collapse" data-parent="#accordion" href="#collapse5">
								5. How do I share my Story ?
							</a>
    					</h4>
    				</div>
    				<div id="collapse5" class="panel-collapse collapse">
      					<div class="panel-body">
      						To share your story, you can write a new story in the Stories tab in the Left Sidebar. Every story saved as draft will only be visible to you. You can edit that later. Every story submitted to be published will forst go through a moderation by some moderators and will be published if it does not violate the community guidelines. For community Guidelines, please read the moderation policy of the platform.
      					</div>
    				</div>
  				</div>
  				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title">
							<a data-toggle="collapse" data-parent="#accordion" href="#collapse6">
								6. How to report a Post/Comment that should not be on the platform ?
							</a>
    					</h4>
    				</div>
    				<div id="collapse6" class="panel-collapse collapse">
      					<div class="panel-body">
      						Click on the 'Report' button next to the post/comment that you want to flag as inappropriate. Our team of moderators will review that as soon as possible.
      					</div>
    				</div>
  				</div>
  				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title">
							<a data-toggle="collapse" data-parent="#accordion" href="#collapse7">
								7. What are Psych-Tests? 
							</a>
    					</h4>
    				</div>
    				<div id="collapse7" class="panel-collapse collapse">
      					<div class="panel-body">
      						Psych-tests or Psychological Testing is a way of standardized measurement of sample of behaviour. ’Sample of behaviour’ refers to the performance of an individual in tasks that have been prescribed beforehand. The science behind psychological testing is called psychometrics. These tests have a series of questions in an MCQ format with a limited number of options to each question to choose from. Each option has a different weight assigned to itself for every question. These questions and their responses are then summed up to produce a score. A score on a well-recognized test usually reflects a psychological behavior. Differences in the score usually reflect the individual differences one has on that particular psychological behaviour.
      					</div>
    				</div>
  				</div>
			</div> <!-- Accordation closed ! -->
		</div>
	</div>
</div>


<?php
// _________________________________FOOTER_______________________________
	include(BASE_URL.'/src/header/footer.php'); // Includes Script
// _________________________________FOOTER_______________________________
?>
