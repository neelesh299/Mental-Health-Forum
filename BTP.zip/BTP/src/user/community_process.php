<?php 
	$servername = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "btp_project";

	// Create connection
	$conn = mysqli_connect($servername, $user, $pass, $dbname);
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}

	$sql = "select * from user_login where level=1";
	$result = mysqli_query($conn, $sql);

	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$id=$row['id'];

			$sql2 = "select * from user_data where id='$id'";
			$result2 = mysqli_query($conn, $sql2);
			$row = $result->fetch_assoc();
			$firstname = $row['firstname'];
			$lastname = $row['lastname'];
			$avatar = $row['avatar'];
			$about = $row['about'];
    	}
	}

?>